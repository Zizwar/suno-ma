
import { View, Text, FlatList, TouchableOpacity, StyleSheet, Modal } from 'react-native';

const ModalPicker = ({ data, onSelect }) => {
  return (
    <View style={styles.modalBackground}>
      <View style={styles.modalContainer}>
        <FlatList
          data={data}
          keyExtractor={(item, index) => index.toString()}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={styles.optionContainer}
              onPress={() => onSelect(item)}
            >
              <Text style={styles.optionText}>{item.text}</Text>
            </TouchableOpacity>
          )}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  modalBackground: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContainer: {
    width: '80%',
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 16,
  },
  optionContainer: {
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
  optionText: {
    fontSize: 18,
  },
});

export default ModalPicker;
