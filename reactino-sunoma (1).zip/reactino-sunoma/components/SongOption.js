import React from 'react';
import { TouchableOpacity, Text, StyleSheet } from 'react-native';

const SongOption = ({ option, isSelected, onSelect }) => {
  return (
    <TouchableOpacity
      style={[styles.option, isSelected ? styles.selected : null]}
      onPress={onSelect}
    >
      <Text>{option.name} - {option.style}</Text>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  option: {
    padding: 8,
    borderWidth: 1,
    borderRadius: 4,
    marginBottom: 4,
  },
  selected: {
    backgroundColor: '#ddd',
  },
});

export default SongOption;
