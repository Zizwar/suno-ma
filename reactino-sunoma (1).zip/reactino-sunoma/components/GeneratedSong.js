import React, { useState } from 'react';
import { View, Text, Image, Button, TouchableOpacity, Alert } from 'react-native';
import * as FileSystem from 'expo-file-system';
import { Audio } from 'expo-av';

const GeneratedSong = ({ song, onDelete }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const sound = useRef(new Audio.Sound());

  const playSound = async (audioUrl) => {
    try {
      if (isPlaying) {
        await sound.current.pauseAsync();
        setIsPlaying(false);
      } else {
        await sound.current.loadAsync({ uri: audioUrl });
        await sound.current.playAsync();
        setIsPlaying(true);
      }
    } catch (error) {
      console.log('Error playing sound:', error);
    }
  };

  const downloadAudio = async (audioUrl) => {
    try {
      const uri = FileSystem.documentDirectory + `${song.id}.mp3`;
      await FileSystem.downloadAsync(audioUrl, uri);
      Alert.alert('Download complete', `File downloaded to ${uri}`);
    } catch (error) {
      console.log('Error downloading audio file:', error);
      Alert.alert('Error', 'Failed to download audio file');
    }
  };

  return (
    <View style={{ marginTop: 16, padding: 8, borderWidth: 1, borderRadius: 8 }}>
      <Text>{song.metadata.prompt}</Text>
      {song.image_url && (
        <Image
          source={{ uri: song.image_url }}
          style={{ width: '100%', height: 200, marginTop: 8 }}
        />
      )}
      {song.audio_url && (
        <Button title={isPlaying ? "Pause Audio" : "Play Audio"} onPress={() => playSound(song.audio_url)} />
      )}
      {song.video_url && (
        <TouchableOpacity onPress={() => Alert.alert('Video URL', song.video_url)}>
          <Text style={{ color: 'blue', marginTop: 8 }}>Watch Video</Text>
        </TouchableOpacity>
      )}
      {song.audio_url && (
        <Button title="Download Audio" onPress={() => downloadAudio(song.audio_url)} />
      )}
      <Button title="Delete" onPress={() => onDelete(song.id)} style={{ marginTop: 8 }} />
    </View>
  );
};

export default GeneratedSong;
