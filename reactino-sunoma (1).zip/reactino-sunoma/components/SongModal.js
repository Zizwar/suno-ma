
import { View, Text, Button, Modal, TouchableOpacity, FlatList } from 'react-native';

const SongModal = ({ visible, data, type, onSelect, onClose }) => {
  return (
    <Modal
      visible={visible}
      transparent={true}
      onRequestClose={onClose}
    >
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: 'rgba(0,0,0,0.5)' }}>
        <View style={{ backgroundColor: 'white', padding: 20, borderRadius: 10, width: '80%', maxHeight: '80%' }}>
          <Text style={{ fontSize: 18, marginBottom: 10 }}>Select {type}</Text>
          <FlatList
            data={data}
            keyExtractor={(item, index) => index.toString()}
            renderItem={({ item }) => (
              <TouchableOpacity onPress={() => onSelect(item)} style={{ padding: 10, borderBottomWidth: 1 }}>
                <Text>{item.text}</Text>
              </TouchableOpacity>
            )}
          />
          <Button title="Close" onPress={onClose} />
        </View>
      </View>
    </Modal>
  );
};

export default SongModal;
