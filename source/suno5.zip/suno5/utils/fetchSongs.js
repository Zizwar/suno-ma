// sunocloudv4/utils/fetchSongs.js

export const fetchSongs = async () => {
  try {
    const response = await fetch('https://suno.deno.dev/all-songs');
    const data = await response.json();
    return data;
    return data.songs.map(song => ({
      id: song.id,
      title: song.metadata.prompt || 'بدون عنوان',
      artist: song.display_name,
      subtitle: song.metadata.tags,
      image_url: song.image_url,
      audio_url: song.audio_url,
      video_url: song.video_url,
      metadata: song.metadata
    }));
  } catch (error) {
    console.error('خطأ في جلب الأغاني:', error);
    throw error;
  }
};

export const generateSong = async (requestData) => {
  try {
    const response = await fetch('https://suno.deno.dev/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(requestData),
    });
    const result = await response.json();
    return result;
  } catch (error) {
    console.error('خطأ:', error);
    throw error;
  }
};

export const getSongMetadata = async (ids) => {
  try {
    const response = await fetch(`https://suno.deno.dev/metadata?ids=${ids}`);
    const result = await response.json();
    return result;
  } catch (error) {
    console.error('خطأ:', error);
    throw error;
  }
};