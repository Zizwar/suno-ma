// sunocloudv4/screens/HomeScreen.js
import React, { useState, useEffect } from 'react';
import { View, ScrollView, TouchableOpacity, StyleSheet, Modal } from 'react-native';
import { Button, Icon, Text, Card } from 'react-native-elements';
import { Audio } from 'expo-av';
import Player from '../components/Player';
import SongListItem from '../components/SongListItem';
import SongDetailsModal from '../components/SongDetailsModal';
import CreateSongScreen from './CreateSongScreen';
import { fetchSongs } from '../utils/fetchSongs';

const HomeScreen = ({ navigation }) => {
  const [createSongModalVisible, setCreateSongModalVisible] = useState(false);
  const [detailsModalVisible, setDetailsModalVisible] = useState(false);
  const [selectedSong, setSelectedSong] = useState(null);
  const [currentSongIndex, setCurrentSongIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [sound, setSound] = useState();
  const [songs, setSongs] = useState([]);

  useEffect(() => {
    loadSongs();
  }, []);

  const loadSongs = async () => {
    try {
     const data = await  fetchSongs();
      setSongs(data.songs.map(item => item));
    } catch (error) {
      console.error('Error loading songs:', error);
    }
  };

  async function playSound(audioUrl) {
    if (sound) {
      await sound.unloadAsync();
    }
    const { sound: newSound } = await Audio.Sound.createAsync({ uri: audioUrl });
    setSound(newSound);
    await newSound.playAsync();
    setIsPlaying(true);
  }

  useEffect(() => {
    return sound
      ? () => {
          sound.unloadAsync();
        }
      : undefined;
  }, [sound]);

  const handlePlayPause = () => {
    if (sound) {
      if (isPlaying) {
        sound.pauseAsync();
      } else {
        sound.playAsync();
      }
      setIsPlaying(!isPlaying);
    } else if (songs[currentSongIndex]) {
      playSound(songs[currentSongIndex].audio_url);
    }
  };

  const handleNext = () => {
    const nextIndex = (currentSongIndex + 1) % songs.length;
    setCurrentSongIndex(nextIndex);
    playSound(songs[nextIndex].audio_url);
  };

  const handlePrevious = () => {
    const prevIndex = (currentSongIndex - 1 + songs.length) % songs.length;
    setCurrentSongIndex(prevIndex);
    playSound(songs[prevIndex].audio_url);
  };

  const handleSongPress = (index) => {
    setCurrentSongIndex(index);
    playSound(songs[index].audio_url);
  };

  const handleSongLongPress = (song) => {
    setSelectedSong(song);
    setDetailsModalVisible(true);
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.logo}>SUN</Text>
        <Button title="Subscribe" buttonStyle={styles.subscribeButton} />
        <Icon name="search" type="font-awesome" color="#fff" size={20} />
        <Icon name="bars" type="font-awesome" color="#fff" size={20} />
      </View>
 <ScrollView>
        {songs.map((song, index) => (
          <SongListItem 
            key={song.id} 
            song={song} 
            onPress={() => handleSongPress(index)}
            onLongPress={() => handleSongLongPress(song)}
          />
        ))}
        {songs.map((song, index) => (
          <SongListItem
            key={song.id}
            song={song}
            onPress={() => handleSongPress(index)}
            onLongPress={() => handleSongLongPress(song)}
            isPlaying={index === currentSongIndex}
            rightContent={
              <TouchableOpacity onPress={() => console.log(song)}>
                <Icon name="edit" type="material" color="#fff" />
              </TouchableOpacity>
            }
          />
        ))}
        {songs.length === 0 && (
          <Card>
            <Card.Title>No songs in your library yet.</Card.Title>
          </Card>
        )}
      </ScrollView>
   
      {songs[currentSongIndex] && (
        <Player 
          currentSong={songs[currentSongIndex]} 
          isPlaying={isPlaying}
          onPlayPause={handlePlayPause}
          onNext={handleNext}
          onPrevious={handlePrevious}
        />
      )}
      <TouchableOpacity 
        style={styles.floatingButton} 
        onPress={() => setCreateSongModalVisible(true)}
      >
        <Icon name="add" type="material" color="#fff" size={30} />
      </TouchableOpacity>
      <Modal
        animationType="slide"
        transparent={true}
        visible={createSongModalVisible}
        onRequestClose={() => setCreateSongModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <CreateSongScreen 
            isModal={true} 
            onClose={() => setCreateSongModalVisible(false)}
          />
        </View>
      </Modal>
      <SongDetailsModal
        visible={detailsModalVisible}
        song={selectedSong}
        onClose={() => setDetailsModalVisible(false)}
        navigation={navigation}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    backgroundColor: '#000' 
  },
  header: { 
    flexDirection: 'row', 
    justifyContent: 'space-between', 
    alignItems: 'center', 
    padding: 10 
  },
  logo: { 
    color: '#fff', 
    fontSize: 24, 
    fontWeight: 'bold' 
  },
  subscribeButton: { 
    backgroundColor: '#333' 
  },
  floatingButton: { 
    position: 'absolute', 
    right: 20, 
    bottom: 70, 
    backgroundColor: '#f50', 
    width: 60, 
    height: 60, 
    borderRadius: 30, 
    justifyContent: 'center', 
    alignItems: 'center' 
  },
  modalContainer: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default HomeScreen;