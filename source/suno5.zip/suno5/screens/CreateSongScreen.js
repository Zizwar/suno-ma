// sunocloudv4/screens/CreateSongScreen.js
import React, { useState, useEffect } from 'react';
import { View, ScrollView, Switch, StyleSheet, Alert } from 'react-native';
import { Input, Button, Card, Text, Icon } from 'react-native-elements';
import InstrumentModal from '../components/InstrumentModal';
import SongModal from '../components/SongModal';
import AdvancedPromptModal from '../components/AdvancedPromptModal';
import { generateSong } from '../utils/fetchSongs';

const CreateSongScreen = ({ navigation, route, isModal = false, onClose }) => {
  const [title, setTitle] = useState('');
  const [tag, setTag] = useState('');
  const [prompt, setPrompt] = useState('');
  const [makeInstrumental, setMakeInstrumental] = useState(false);
  const [instrumentModalVisible, setInstrumentModalVisible] = useState(false);
  const [songModalVisible, setSongModalVisible] = useState(false);
  const [structureModalVisible, setStructureModalVisible] = useState(false);
  const [advancedModalVisible, setAdvancedModalVisible] = useState(false);
  const [songOptions, setSongOptions] = useState([]);
  const [continueClip, setContinueClip] = useState(null);

  useEffect(() => {
    if (route?.params?.song) {
      const { song } = route.params;
      setTitle(song.title);
      setTag(song.metadata?.tags || '');
      setPrompt(song.metadata?.prompt || '');
      setMakeInstrumental(song.metadata?.has_vocal === false);
      setContinueClip(song.metadata?.audio_prompt_id ? { id: song.metadata.audio_prompt_id, time: song.metadata.history?.[0]?.continue_at } : null);
    }
  }, [route?.params?.song]);

  useEffect(() => {
    loadSongOptions();
  }, []);

  const loadSongOptions = async () => {
    try {
      const response = await fetch('https://studio-api.suno.ai/api/playlist/1190bf92-10dc-4ce5-968a-7a377f37f984/?page=1');
      const data = await response.json();
      setSongOptions(data.playlist_clips.map(clip => ({
        id: clip.clip.id,
        title: clip.clip.title,
        artist: clip.clip.display_name,
        time: 56
      })));
    } catch (error) {
      console.error('Error loading song options:', error);
    }
  };

  const handleOpenModal = (type) => {
    if (type === 'song') setSongModalVisible(true);
    else if (type === 'instrument') setInstrumentModalVisible(true);
    else if (type === 'structure') setStructureModalVisible(true);
  };

  const handleModalSelect = (item) => {
    if (item.type === 'instrument' || item.type === 'structure') {
      setPrompt((prevPrompt) => `${prevPrompt} ${item.value}\n`);
    } else if (item.type === 'song') {
      setContinueClip(item);
    }
    
    if (item.type === 'instrument') setInstrumentModalVisible(false);
    if (item.type === 'structure') setStructureModalVisible(false);
    if (item.type === 'song') setSongModalVisible(false);
  };

  const handleGenerate = async () => {
    const requestData = {
      title,
      tags: tag,
      prompt: makeInstrumental ? null : prompt,
      continue_clip_id: continueClip?.id,
      continue_at: continueClip?.time,
      make_instrumental: makeInstrumental,
      mv: 'chirp-v3-5',
    };

    try {
      const result = await generateSong(requestData);
      Alert.alert('Success', 'Song generated successfully!');
      if (isModal && onClose) {
        onClose();
      } else {
        navigation.navigate('Library');
      }
    } catch (error) {
      console.error('Error generating song:', error);
      Alert.alert('Error', 'Failed to generate song. Please try again.');
    }
  };

  const handleUpdatePrompt = (newPrompt) => {
    setPrompt(newPrompt);
  };

  return (
    <ScrollView style={styles.container}>
      <Card containerStyle={styles.card}>
        <Card.Title>{isModal ? "Create New Song" : "Create Song"}</Card.Title>
        <Input
          label="Title"
          value={title}
          onChangeText={setTitle}
          placeholder="Enter song title"
          inputStyle={styles.input}
        />
        <Input
          label="Tag"
          value={tag}
          onChangeText={setTag}
          placeholder="Enter tag"
          inputStyle={styles.input}
        />
        <Input
          label="Prompt"
          value={prompt}
          onChangeText={handleUpdatePrompt}
          placeholder="Enter song prompt"
          multiline
          numberOfLines={4}
          textAlignVertical="top"
          disabled={makeInstrumental}
          inputStyle={styles.input}
        />
        <View style={styles.switchContainer}>
          <Text style={styles.switchLabel}>Make Instrumental</Text>
          <Switch
            value={makeInstrumental}
            onValueChange={setMakeInstrumental}
            trackColor={{ false: "#767577", true: "#81b0ff" }}
            thumbColor={makeInstrumental ? "#f5dd4b" : "#f4f3f4"}
          />
        </View>
        <View style={styles.buttonContainer}>
          <Button
            title="Select Song"
            onPress={() => setSongModalVisible(true)}
            icon={<Icon name="queue-music" color="#ffffff" size={24} />}
            buttonStyle={[styles.button, styles.songButton]}
            containerStyle={styles.buttonWrapper}
          />
          <Button
            title="Add Structure"
            onPress={() => handleOpenModal('structure')}
            icon={<Icon name="format-list-bulleted" color="#ffffff" />}
            buttonStyle={[styles.button, styles.structureButton]}
            containerStyle={styles.buttonWrapper}
          />
          <Button
            title="Select Instrument"
            onPress={() => setInstrumentModalVisible(true)}
            icon={<Icon name="music-note" color="#ffffff" />}
            buttonStyle={[styles.button, styles.instrumentButton]}
            containerStyle={styles.buttonWrapper}
          />
          <Button
            title="Advanced Prompt"
            onPress={() => setAdvancedModalVisible(true)}
            icon={<Icon name="edit" color="#ffffff" />}
            buttonStyle={[styles.button, styles.advancedButton]}
            containerStyle={styles.buttonWrapper}
          />
        </View>
        <Button
          title="Generate Song"
          onPress={handleGenerate}
          icon={<Icon name="music" color="#ffffff" />}
          buttonStyle={styles.generateButton}
        />
        {isModal && (
          <Button
            title="Close"
            onPress={onClose}
            buttonStyle={styles.closeButton}
          />
        )}
      </Card>

      <InstrumentModal
        visible={instrumentModalVisible}
        onClose={() => setInstrumentModalVisible(false)}
        onSelectInstrument={(value) => handleModalSelect({ type: 'instrument', value })}
      />
   
      <SongModal
        visible={structureModalVisible}
     //   data={structureOptions.map(item => ({ ...item, type: 'structure' }))}
        type="structure"
        onSelect={handleModalSelect}
        onClose={() => setStructureModalVisible(false)}
      />

      <SongModal
        visible={songModalVisible}
        data={songOptions.map(item => ({ ...item, type: 'song' }))}
        type="song"
        onSelect={handleModalSelect}
        onClose={() => setSongModalVisible(false)}
      />
      
      <AdvancedPromptModal
        visible={advancedModalVisible}
        onClose={() => setAdvancedModalVisible(false)}
        onUpdatePrompt={handleUpdatePrompt}
        prompt={prompt}
      />
    </ScrollView>
  );
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#121212',
  },
  card: {
    backgroundColor: '#1E1E1E',
    borderColor: '#333',
    borderRadius: 10,
    padding: 15,
  },
  input: {
    color: '#fff',
    fontSize: 16,
  },
  switchContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginVertical: 10,
  },
  switchLabel: {
    color: '#fff',
    fontSize: 16,
  },
  buttonContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginTop: 10,
  },
  buttonWrapper: {
    width: '48%',
    marginBottom: 10,
  },
  button: {
    borderRadius: 25,
    paddingVertical: 10,
  },
  songButton: {
    backgroundColor: '#4a90e2',
  },
  structureButton: {
    backgroundColor: '#f39c12',
  },
  instrumentButton: {
    backgroundColor: '#2ecc71',
  },
  advancedButton: {
    backgroundColor: '#e74c3c',
  },
  generateButton: {
    marginTop: 20,
    backgroundColor: '#8e44ad',
    borderRadius: 25,
    paddingVertical: 12,
  },
  closeButton: {
    marginTop: 10,
    backgroundColor: '#95a5a6',
    borderRadius: 25,
    paddingVertical: 12,
  },
});
export default CreateSongScreen;