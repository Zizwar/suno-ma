// sunocloudv4/screens/LibraryScreen.js
import React, { useState, useEffect } from 'react';
import { View, ScrollView, StyleSheet, Alert, RefreshControl, TouchableOpacity } from 'react-native';
import { Card, Button, Icon } from 'react-native-elements';
import SongListItem from '../components/SongListItem';
import SongDetailsModal from '../components/SongDetailsModal';

const LibraryScreen = ({ navigation }) => {
  const [songs, setSongs] = useState([]);
  const [refreshing, setRefreshing] = useState(false);
  const [detailsModalVisible, setDetailsModalVisible] = useState(false);
  const [selectedSong, setSelectedSong] = useState(null);
  const [currentSongIndex, setCurrentSongIndex] = useState(null);

  useEffect(() => {
    loadSongs();
  }, []);

  const loadSongs = async () => {
    try {
      const response = await fetch('https://studio-api.suno.ai/api/playlist/1190bf92-10dc-4ce5-968a-7a377f37f984/?page=1');
      const data = await response.json();
      setSongs(data.playlist_clips.map(item => item.clip));
    } catch (error) {
      console.error('Error loading songs:', error);
      Alert.alert('Error', 'Failed to load songs. Please try again.');
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await loadSongs();
    setRefreshing(false);
  };

  const handlePlay = (index) => {
    setCurrentSongIndex(index);
    // Here you would typically update the global audio player state
    console.log(`Playing song: ${songs[index].title}`);
  };

  const handleEdit = (song) => {
    setDetailsModalVisible(false);
    navigation.navigate('Create', { song: song });
  };

  const handleDelete = async (songId) => {
    try {
      const updatedSongs = songs.filter(song => song.id !== songId);
      setSongs(updatedSongs);
      setDetailsModalVisible(false);
      Alert.alert('Success', 'Song deleted successfully!');
    } catch (error) {
      console.error('Error deleting song:', error);
      Alert.alert('Error', 'Failed to delete song. Please try again.');
    }
  };

  const handleSongPress = (index) => {
    handlePlay(index);
  };

  const handleSongLongPress = (song) => {
    setSelectedSong(song);
    setDetailsModalVisible(true);
  };

  return (
    <View style={styles.container}>
      <ScrollView 
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={handleRefresh}
          />
        }
      >
        {songs.map((song, index) => (
          <SongListItem
            key={song.id}
            song={song}
            onPress={() => handleSongPress(index)}
            onLongPress={() => handleSongLongPress(song)}
            isPlaying={index === currentSongIndex}
            rightContent={
              <TouchableOpacity onPress={() => handleEdit(song)}>
                <Icon name="edit" type="material" color="#fff" />
              </TouchableOpacity>
            }
          />
        ))}
        {songs.length === 0 && (
          <Card>
            <Card.Title>No songs in your library yet.</Card.Title>
          </Card>
        )}
      </ScrollView>
      <SongDetailsModal
        visible={detailsModalVisible}
        song={selectedSong}
        onClose={() => setDetailsModalVisible(false)}
        onEdit={handleEdit}
        onDelete={handleDelete}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
});

export default LibraryScreen;