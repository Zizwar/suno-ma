// ControlButtons.js

import React, { useState, useEffect } from 'react';
import { View, Alert } from 'react-native';
import { Button, Icon, Overlay, ListItem, Input } from 'react-native-elements';
import { useTranslation } from 'react-i18next';
import AsyncStorage from '@react-native-async-storage/async-storage';
import InstrumentModal from './InstrumentModal';
import AdvancedPromptModal from './AdvancedPromptModal';
import AdvancedSongModal from './AdvancedSongModal';
import { styles } from '../styles/CreateSongStyles';

const ControlButtons = ({
  title,
  tag,
  prompt,
  setPrompt,
  makeInstrumental,
  continueClip,
  selectedTime,
  handleGenerate,
  isLoading,
  isModal,
  onClose,
  theme,
  inputText300,
  setInputText300,
  inputModalVisible,
  setInputModalVisible,
  handleInputSubmit,
}) => {
  const { t } = useTranslation();
  const handleAssistantButton = () => {
    setInputModalVisible(true);
  };
  const [instrumentModalVisible, setInstrumentModalVisible] = useState(false);
  const [songOptionsVisible, setSongOptionsVisible] = useState(false);
  const [structureOptionsVisible, setStructureOptionsVisible] = useState(false);
  const [advancedPromptModalVisible, setAdvancedPromptModalVisible] =
    useState(false);
  const [savedItems, setSavedItems] = useState([]);
  const [savedItemsOverlayVisible, setSavedItemsOverlayVisible] =
    useState(false);
  const [saveNameModalVisible, setSaveNameModalVisible] = useState(false);
  const [saveName, setSaveName] = useState('');

  useEffect(() => {
    loadSavedItems();
  }, []);

  const loadSavedItems = async () => {
    try {
      const savedItemsString = await AsyncStorage.getItem('savedItems');
      if (savedItemsString) {
        setSavedItems(JSON.parse(savedItemsString));
      }
    } catch (error) {
      console.error('Error loading saved items:', error);
    }
  };

  const handleSave = async () => {
    setSaveName(title);
    setSaveNameModalVisible(true);
  };

  const confirmSave = async () => {
    try {
      const newItem = {
        name: saveName,
        title,
        tag,
        prompt,
        makeInstrumental,
        continueClip,
        selectedTime,
      };
      const updatedItems = [...savedItems, newItem];
      await AsyncStorage.setItem('savedItems', JSON.stringify(updatedItems));
      setSavedItems(updatedItems);
      Alert.alert(t('success'), t('itemSavedSuccess'));
      setSaveNameModalVisible(false);
    } catch (error) {
      console.error('Error saving item:', error);
      Alert.alert(t('error'), t('itemSaveFailed'));
    }
  };

  const handleLoadSavedItem = (savedItem) => {
    if (typeof onLoadSavedItem === 'function') {
      onLoadSavedItem(savedItem);
    }
    setSavedItemsOverlayVisible(false);
  };

  const handleDeleteSavedItem = async (index) => {
    try {
      const updatedItems = savedItems.filter((_, i) => i !== index);
      await AsyncStorage.setItem('savedItems', JSON.stringify(updatedItems));
      setSavedItems(updatedItems);
      Alert.alert(t('success'), t('itemDeletedSuccess'));
    } catch (error) {
      console.error('Error deleting item:', error);
      Alert.alert(t('error'), t('itemDeleteFailed'));
    }
  };

  const handleModalSelect = (item, type) => {
    if (type === 'instrument' || type === 'structure') {
      setPrompt((prevPrompt) => prevPrompt + `${item.value}\n`);
    } else if (type === 'song') {
      // Implement song selection logic
      console.log('Selected song:', item);
    }

    if (type === 'instrument') setInstrumentModalVisible(false);
    if (type === 'structure') setStructureOptionsVisible(false);
    if (type === 'song') setSongOptionsVisible(false);
  };

  return (
    <View>
      <Button
        title={t('smartAssistant')}
        icon={<Icon name="assistant" color={theme.colors.white} />}
        onPress={handleAssistantButton}
        containerStyle={styles.assistantButton}
        buttonStyle={{ backgroundColor: theme.colors.secondary }}
      />
      <View style={styles.buttonGrid}>
        <Button
          title={t('song')}
          icon={<Icon name="queue-music" color={theme.colors.white} />}
          onPress={() => setSongOptionsVisible(true)}
          containerStyle={styles.gridButton}
          buttonStyle={{ backgroundColor: theme.colors.primary }}
        />
        <Button
          title={t('structure')}
          icon={<Icon name="format-list-bulleted" color={theme.colors.white} />}
          onPress={() => setStructureOptionsVisible(true)}
          containerStyle={styles.gridButton}
          buttonStyle={{ backgroundColor: theme.colors.primary }}
        />
        <Button
          title={t('instrument')}
          icon={<Icon name="music-note" color={theme.colors.white} />}
          onPress={() => setInstrumentModalVisible(true)}
          containerStyle={styles.gridButton}
          buttonStyle={{ backgroundColor: theme.colors.primary }}
        />
        <Button
          title={t('advanced')}
          icon={<Icon name="edit" color={theme.colors.white} />}
          onPress={() => setAdvancedPromptModalVisible(true)}
          containerStyle={styles.gridButton}
          buttonStyle={{ backgroundColor: theme.colors.primary }}
        />
      </View>
      <View style={styles.actionButtons}>
        <Button
          title={t('save')}
          icon={<Icon name="save" color={theme.colors.white} />}
          onPress={handleSave}
          containerStyle={styles.actionButton}
          buttonStyle={{ backgroundColor: theme.colors.primary }}
        />
        <Button
          title={t('savedList')}
          icon={<Icon name="list" color={theme.colors.white} />}
          onPress={() => setSavedItemsOverlayVisible(true)}
          containerStyle={styles.actionButton}
          buttonStyle={{ backgroundColor: theme.colors.primary }}
        />
      </View>

      <Button
        title={t('generate')}
        icon={<Icon name="noise-aware" color={theme.colors.white} />}
        onPress={handleGenerate}
        loading={isLoading}
        containerStyle={styles.generateButton}
        buttonStyle={{ backgroundColor: theme.colors.primary }}
      />
      {isModal && (
        <Button
          title={t('close')}
          onPress={onClose}
          type="outline"
          containerStyle={{ marginTop: 10 }}
          buttonStyle={{ borderColor: theme.colors.primary }}
          titleStyle={{ color: theme.colors.primary }}
        />
      )}
      <Overlay
        isVisible={inputModalVisible}
        onBackdropPress={() => setInputModalVisible(false)}
        overlayStyle={[
          styles.inputOverlay,
          { backgroundColor: theme.colors.background },
        ]}>
        <View>
          <Input
            value={inputText300}
            onChangeText={setInputText300}
            placeholder={t('enterUpTo300Chars')}
            inputStyle={{ color: theme.colors.text }}
            labelStyle={{ color: theme.colors.text }}
            placeholderTextColor={theme.colors.grey3}
            multiline
            numberOfLines={3}
            maxLength={300}
            containerStyle={styles.inputContainer}
          />
          <Button
            title={isLoading ? t('generating') : t('submit')}
            onPress={handleInputSubmit}
            disabled={isLoading}
            loading={isLoading}
            containerStyle={{ marginTop: 20 }}
            buttonStyle={{ backgroundColor: theme.colors.primary }}
          />
          <Button
            title={t('cancel')}
            onPress={() => setInputModalVisible(false)}
            type="outline"
            containerStyle={{ marginTop: 10 }}
            buttonStyle={{ borderColor: theme.colors.primary }}
            titleStyle={{ color: theme.colors.primary }}
          />
        </View>
      </Overlay>
      <InstrumentModal
        visible={instrumentModalVisible}
        onClose={() => setInstrumentModalVisible(false)}
        onSelectInstrument={(value) =>
          handleModalSelect({ value }, 'instrument')
        }
        theme={theme}
      />

      <AdvancedSongModal
        visible={songOptionsVisible}
        onClose={() => setSongOptionsVisible(false)}
        onSelectSong={(song) => handleModalSelect(song, 'song')}
        theme={theme}
      />

      <AdvancedPromptModal
        visible={advancedPromptModalVisible}
        onClose={() => setAdvancedPromptModalVisible(false)}
        onUpdatePrompt={setPrompt}
        prompt={prompt}
        theme={theme}
      />

      <Overlay
        isVisible={savedItemsOverlayVisible}
        onBackdropPress={() => setSavedItemsOverlayVisible(false)}
        overlayStyle={[
          styles.savedItemsOverlay,
          { backgroundColor: theme.colors.grey5 },
        ]}>
        <View>
          {savedItems.map((item, index) => (
            <ListItem key={index} bottomDivider>
              <ListItem.Content>
                <ListItem.Title>{item.name}</ListItem.Title>
              </ListItem.Content>
              <Button
                icon={<Icon name="edit" color={theme.colors.primary} />}
                onPress={() => handleLoadSavedItem(item)}
                type="clear"
              />
              <Button
                icon={<Icon name="delete" color={theme.colors.error} />}
                onPress={() => handleDeleteSavedItem(index)}
                type="clear"
              />
            </ListItem>
          ))}
          <Button
            title={t('close')}
            onPress={() => setSavedItemsOverlayVisible(false)}
            containerStyle={{ marginTop: 10 }}
            buttonStyle={{ backgroundColor: theme.colors.primary }}
          />
        </View>
      </Overlay>

      <Overlay
        isVisible={saveNameModalVisible}
        onBackdropPress={() => setSaveNameModalVisible(false)}
        overlayStyle={{ backgroundColor: theme.colors.grey5 }}>
        <View>
          <Input
            label={t('itemName')}
            value={saveName}
            onChangeText={setSaveName}
            placeholder={t('enterItemName')}
            inputStyle={{ color: theme.colors.text }}
            labelStyle={{ color: theme.colors.text }}
            placeholderTextColor={theme.colors.grey3}
          />
          <Button
            title={t('save')}
            onPress={confirmSave}
            containerStyle={{ marginTop: 10 }}
            buttonStyle={{ backgroundColor: theme.colors.primary }}
          />
          <Button
            title={t('cancel')}
            onPress={() => setSaveNameModalVisible(false)}
            type="outline"
            containerStyle={{ marginTop: 10 }}
            buttonStyle={{ borderColor: theme.colors.primary }}
            titleStyle={{ color: theme.colors.primary }}
          />
        </View>
      </Overlay>
    </View>
  );
};

export default ControlButtons;
