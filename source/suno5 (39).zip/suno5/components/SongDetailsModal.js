import React, { useState, useEffect } from 'react';
import { View, Text, Image, Modal, StyleSheet, ScrollView, TouchableOpacity, Alert, Dimensions, ActivityIndicator } from 'react-native';
import { Button, Icon, Overlay } from 'react-native-elements';
import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import { Video } from 'expo-av';
import { getSongMetadata } from '../utils/fetchSongs';

const { width, height } = Dimensions.get('window');

const SongDetailsModal = ({ visible, song, onClose, theme }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [metadata, setMetadata] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (song && visible) {
      fetchMetadata();
    }
  }, [song, visible]);

  const fetchMetadata = async () => {
    try {
      setLoading(true);
      const data = await getSongMetadata(song.id);
      if (data && data.metadata && data.metadata.length > 0) {
        setMetadata(data.metadata[0]);
      }
    } catch (error) {
      console.error('Error fetching metadata:', error);
      Alert.alert('Error', 'Failed to fetch song details.');
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = async (type) => {
    if (!metadata) return;

    try {
      let url;
      let fileName;
      switch (type) {
        case 'video':
          url = metadata.video_url;
          fileName = `${metadata.id}_video.mp4`;
          break;
        case 'mp3':
          url = metadata.audio_url;
          fileName = `${metadata.id}_audio.mp3`;
          break;
        case 'wave':
          // Assuming wave URL is available, adjust if needed
          url = metadata.audio_url.replace('.mp3', '.wav');
          fileName = `${metadata.id}_audio.wav`;
          break;
        default:
          throw new Error('Invalid download type');
      }

      const fileUri = `${FileSystem.documentDirectory}${fileName}`;
      const downloadResumable = FileSystem.createDownloadResumable(url, fileUri);
      const { uri } = await downloadResumable.downloadAsync();

      if (await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(uri);
      } else {
        Alert.alert('Success', `File downloaded to ${uri}`);
      }
    } catch (error) {
      console.error('Download error:', error);
      Alert.alert('Error', 'Failed to download the file.');
    }
  };

  const handleVideoPlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  if (!song || !metadata) return null;

  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={visible}
      onRequestClose={onClose}
    >
      <View style={[styles.centeredView, { backgroundColor: theme.colors.background }]}>
        {loading ? (
          <ActivityIndicator size="large" color={theme.colors.primary} />
        ) : (
          <ScrollView style={styles.modalView}>
            <Image source={{ uri: metadata.image_large_url }} style={styles.image} />
            <Text style={[styles.title, { color: theme.colors.text }]}>{metadata.title || 'Untitled'}</Text>
            <Text style={[styles.artist, { color: theme.colors.text }]}>{metadata.display_name}</Text>

            <View style={styles.infoContainer}>
              <InfoItem icon="tag" text={metadata.metadata.tags} theme={theme} />
              <InfoItem icon="clock" text={`${Math.floor(metadata.metadata.duration / 60)}:${(metadata.metadata.duration % 60).toString().padStart(2, '0')}`} theme={theme} />
              <InfoItem icon="calendar" text={new Date(metadata.created_at).toLocaleDateString()} theme={theme} />
              <InfoItem icon="play-circle" text={`Plays: ${metadata.play_count}`} theme={theme} />
              <InfoItem icon="thumbs-up" text={`Upvotes: ${metadata.upvote_count}`} theme={theme} />
            </View>

            <Text style={[styles.sectionTitle, { color: theme.colors.text }]}>Prompt</Text>
            <Text style={[styles.prompt, { color: theme.colors.text }]}>{metadata.metadata.prompt}</Text>

            <Text style={[styles.sectionTitle, { color: theme.colors.text }]}>Downloads</Text>
            <View style={styles.downloadButtons}>
              <DownloadButton icon="video" text="Video" onPress={() => handleDownload('video')} theme={theme} />
              <DownloadButton icon="music" text="MP3" onPress={() => handleDownload('mp3')} theme={theme} />
              <DownloadButton icon="wave-square" text="Wave" onPress={() => handleDownload('wave')} theme={theme} />
            </View>

            <TouchableOpacity onPress={handleVideoPlayPause} style={styles.videoContainer}>
              <Video
                source={{ uri: metadata.video_url }}
                rate={1.0}
                volume={1.0}
                isMuted={false}
                resizeMode="contain"
                shouldPlay={isPlaying}
                isLooping
                style={styles.video}
              />
              <Icon
                name={isPlaying ? 'pause' : 'play'}
                type="font-awesome"
                color="#fff"
                size={50}
                containerStyle={styles.playIcon}
              />
            </TouchableOpacity>
          </ScrollView>
        )}
        <Button 
          title="Close" 
          onPress={onClose} 
          buttonStyle={[styles.closeButton, { backgroundColor: theme.colors.primary }]} 
        />
      </View>
    </Modal>
  );
};

const InfoItem = ({ icon, text, theme }) => (
  <View style={styles.infoItem}>
    <Icon name={icon} type="font-awesome" size={18} color={theme.colors.text} />
    <Text style={[styles.infoText, { color: theme.colors.text }]}>{text}</Text>
  </View>
);

const DownloadButton = ({ icon, text, onPress, theme }) => (
  <TouchableOpacity style={[styles.downloadButton, { backgroundColor: theme.colors.primary }]} onPress={onPress}>
    <Icon name={icon} type="font-awesome" size={20} color="#fff" />
    <Text style={styles.downloadButtonText}>{text}</Text>
  </TouchableOpacity>
);

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalView: {
    width: width * 0.9,
    maxHeight: height * 0.8,
    backgroundColor: 'transparent',
    borderRadius: 20,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  image: {
    width: width * 0.8,
    height: width * 0.8,
    borderRadius: 10,
    alignSelf: 'center',
    marginBottom: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
    textAlign: 'center',
  },
  artist: {
    fontSize: 18,
    marginBottom: 20,
    textAlign: 'center',
  },
  infoContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  infoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '48%',
    marginBottom: 10,
  },
  infoText: {
    marginLeft: 10,
    fontSize: 14,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  prompt: {
    fontSize: 14,
    marginBottom: 20,
  },
  downloadButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  downloadButton: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
    borderRadius: 5,
  },
  downloadButtonText: {
    color: '#fff',
    marginLeft: 5,
  },
  videoContainer: {
    width: '100%',
    aspectRatio: 16 / 9,
    marginBottom: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  video: {
    width: '100%',
    height: '100%',
  },
  playIcon: {
    position: 'absolute',
  },
  closeButton: {
    width: width * 0.9,
    marginTop: 10,
  },
});

export default SongDetailsModal;