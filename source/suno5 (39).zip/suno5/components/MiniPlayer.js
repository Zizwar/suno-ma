import React, { useContext, useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { AudioContext } from '../App';
import { useTheme } from 'react-native-elements';
import { toggleFavorite, isFavorite } from '../utils/favoriteUtils';

const MiniPlayer = () => {
  const { theme } = useTheme();
  const { 
    currentSong, 
    isPlaying, 
    handlePlayPause, 
    handleNext, 
    handlePrevious, 
    togglePlayerModal,
    setMiniPlayerVisible,
    playlist,
    currentIndex
  } = useContext(AudioContext);

  const [isFavoriteSong, setIsFavoriteSong] = useState(false);

  useEffect(() => {
    if (currentSong) {
      checkFavoriteStatus();
    }
  }, [currentSong]);

  const checkFavoriteStatus = async () => {
    if (currentSong) {
      const favoriteStatus = await isFavorite(currentSong.id);
      setIsFavoriteSong(favoriteStatus);
    }
  };

  const handleToggleFavorite = async () => {
    if (currentSong) {
      const newFavoriteStatus = await toggleFavorite(currentSong);
      setIsFavoriteSong(newFavoriteStatus);
    }
  };

  if (!currentSong) return null;

  const handleClose = () => {
    setMiniPlayerVisible(false);
  };

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <TouchableOpacity style={styles.contentContainer} onPress={togglePlayerModal}>
        <Image source={{ uri: currentSong.image_url }} style={styles.image} />
        <View style={styles.textContainer}>
          <Text style={[styles.title, { color: theme.colors.text }]} numberOfLines={1}>{currentSong.title}</Text>
          <Text style={[styles.artist, { color: theme.colors.grey3 }]} numberOfLines={1}>{currentSong.artist || 'Unknown'}</Text>
        </View>
      </TouchableOpacity>
      <View style={styles.controlsContainer}>
        <TouchableOpacity onPress={handlePrevious} disabled={currentIndex === 0}>
          <Ionicons name="play-skip-back" size={24} color={currentIndex === 0 ? theme.colors.grey3 : theme.colors.text} />
        </TouchableOpacity>
        <TouchableOpacity onPress={handlePlayPause}>
          <Ionicons name={isPlaying ? "pause" : "play"} size={24} color={theme.colors.text} />
        </TouchableOpacity>
        <TouchableOpacity onPress={handleNext} disabled={currentIndex === playlist.length - 1}>
          <Ionicons name="play-skip-forward" size={24} color={currentIndex === playlist.length - 1 ? theme.colors.grey3 : theme.colors.text} />
        </TouchableOpacity>
        <TouchableOpacity onPress={handleToggleFavorite}>
          <Ionicons name={isFavoriteSong ? "heart" : "heart-outline"} size={24} color={theme.colors.text} />
        </TouchableOpacity>
      </View>
      <TouchableOpacity onPress={handleClose} style={styles.closeButton}>
        <Ionicons name="close" size={24} color={theme.colors.text} />
      </TouchableOpacity>
    </View>
  );
};


const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 10,
    borderTopWidth: 1,
    borderTopColor: 'rgba(0, 0, 0, 0.1)',
  },
  contentContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  image: {
    width: 40,
    height: 40,
    borderRadius: 4,
    marginRight: 10,
  },
  textContainer: {
    flex: 1,
  },
  title: {
    fontSize: 14,
    fontWeight: 'bold',
  },
  artist: {
    fontSize: 12,
  },
  controlsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: 100,
  },
  closeButton: {
    marginLeft: 10,
  },
});

export default MiniPlayer;