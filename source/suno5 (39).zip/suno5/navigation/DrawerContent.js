import React, { useContext } from 'react';
import { View, StyleSheet, Image, ScrollView } from 'react-native';
import { DrawerContentScrollView, DrawerItem } from '@react-navigation/drawer';
import { Avatar, Text, Switch, Divider } from 'react-native-elements';
import { Ionicons } from '@expo/vector-icons';
import { ThemeContext } from '../utils/ThemeContext';
import { useTranslation } from 'react-i18next';
import AsyncStorage from '@react-native-async-storage/async-storage';

const DrawerContent = (props) => {
  const { isDarkMode, toggleDarkMode } = useContext(ThemeContext);
  const { t } = useTranslation();

  const handleLogout = async () => {
    // Implement logout logic here
    // For example:
    // await AsyncStorage.removeItem('userToken');
    props.navigation.navigate('Login');
  };

  const DrawerItemIcon = ({ name }) => (
    <Ionicons name={name} size={24} color={isDarkMode ? '#ffffff' : '#000000'} />
  );

  return (
    <DrawerContentScrollView 
      {...props}
      style={{backgroundColor: isDarkMode ? '#121212' : '#ffffff'}}
    >
      <View style={styles.drawerContent}>
        <View style={styles.userInfoSection}>
          <View style={styles.userInfo}>
            <Avatar
              rounded
              size="large"
              source={{
                uri: 'https://randomuser.me/api/portraits/men/32.jpg',
              }}
              containerStyle={styles.avatar}
            />
            <View style={styles.userDetails}>
              <Text style={[styles.title, {color: isDarkMode ? '#ffffff' : '#000000'}]}>John Doe</Text>
              <Text style={[styles.caption, {color: isDarkMode ? '#cccccc' : '#666666'}]}>@johndoe</Text>
            </View>
          </View>
        </View>

        <Divider style={[styles.divider, { backgroundColor: isDarkMode ? '#ffffff' : '#000000' }]} />

        <DrawerItem
          icon={() => <DrawerItemIcon name="home-outline" />}
          label={t('home')}
          onPress={() => props.navigation.navigate('Home')}
          labelStyle={[styles.drawerLabel, {color: isDarkMode ? '#ffffff' : '#000000'}]}
        />
        <DrawerItem
          icon={() => <DrawerItemIcon name="library-outline" />}
          label={t('myLibrary')}
          onPress={() => props.navigation.navigate('Library')}
          labelStyle={[styles.drawerLabel, {color: isDarkMode ? '#ffffff' : '#000000'}]}
        />
        <DrawerItem
          icon={() => <DrawerItemIcon name="search-outline" />}
          label={t('explore')}
          onPress={() => props.navigation.navigate('Search')}
          labelStyle={[styles.drawerLabel, {color: isDarkMode ? '#ffffff' : '#000000'}]}
        />
        <DrawerItem
          icon={() => <DrawerItemIcon name="add-circle-outline" />}
          label={t('createSong')}
          onPress={() => props.navigation.navigate('Create')}
          labelStyle={[styles.drawerLabel, {color: isDarkMode ? '#ffffff' : '#000000'}]}
        />
        <DrawerItem
          icon={() => <DrawerItemIcon name="download-outline" />}
          label={t('downloads')}
          onPress={() => props.navigation.navigate('Download')}
          labelStyle={[styles.drawerLabel, {color: isDarkMode ? '#ffffff' : '#000000'}]}
        />
        <DrawerItem
          icon={() => <DrawerItemIcon name="heart-outline" />}
          label={t('favorites')}
          onPress={() => props.navigation.navigate('Favorites')}
          labelStyle={[styles.drawerLabel, {color: isDarkMode ? '#ffffff' : '#000000'}]}
        />

        <Divider style={[styles.divider, { backgroundColor: isDarkMode ? '#ffffff' : '#000000' }]} />

        <DrawerItem
          icon={() => <DrawerItemIcon name="settings-outline" />}
          label={t('settings')}
          onPress={() => props.navigation.navigate('Settings')}
          labelStyle={[styles.drawerLabel, {color: isDarkMode ? '#ffffff' : '#000000'}]}
        />
        <DrawerItem
          icon={() => <DrawerItemIcon name="person-outline" />}
          label={t('profile')}
          onPress={() => props.navigation.navigate('Profile')}
          labelStyle={[styles.drawerLabel, {color: isDarkMode ? '#ffffff' : '#000000'}]}
        />
        <DrawerItem
          icon={() => <DrawerItemIcon name="help-circle-outline" />}
          label={t('helpAndSupport')}
          onPress={() => props.navigation.navigate('HelpSupport')}
          labelStyle={[styles.drawerLabel, {color: isDarkMode ? '#ffffff' : '#000000'}]}
        />

        <Divider style={[styles.divider, { backgroundColor: isDarkMode ? '#ffffff' : '#000000' }]} />

        <View style={styles.preference}>
          <Text style={{color: isDarkMode ? '#ffffff' : '#000000'}}>
            {isDarkMode ? t('lightMode') : t('darkMode')}
          </Text>
          <Switch
            value={isDarkMode}
            onValueChange={toggleDarkMode}
            trackColor={{ false: "#767577", true: "#81b0ff" }}
            thumbColor={isDarkMode ? "#f5dd4b" : "#f4f3f4"}
          />
        </View>

        <DrawerItem
          icon={() => <DrawerItemIcon name="log-out-outline" />}
          label={t('logout')}
          onPress={handleLogout}
          labelStyle={[styles.drawerLabel, {color: isDarkMode ? '#ffffff' : '#000000'}]}
        />
      </View>
    </DrawerContentScrollView>
  );
};

const styles = StyleSheet.create({
  drawerContent: {
    flex: 1,
    paddingTop: 10,
  },
  userInfoSection: {
    paddingLeft: 20,
    marginBottom: 15,
  },
  userInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  avatar: {
    marginRight: 15,
  },
  userDetails: {
    flexDirection: 'column',
  },
  title: {
    fontSize: 18,
    marginTop: 3,
    fontWeight: 'bold',
  },
  caption: {
    fontSize: 14,
    lineHeight: 14,
  },
  divider: {
    marginVertical: 10,
  },
  drawerLabel: {
    fontSize: 16,
  },
  preference: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 12,
    paddingHorizontal: 16,
    alignItems: 'center',
  },
});

export default DrawerContent;