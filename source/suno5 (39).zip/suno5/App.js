import React, { useState, useEffect, useContext } from 'react';
import { View, TouchableOpacity, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { ThemeProvider as RNEThemeProvider, Icon } from 'react-native-elements';
import { I18nextProvider } from 'react-i18next';
import * as BackgroundFetch from 'expo-background-fetch';
import * as TaskManager from 'expo-task-manager';
import { Audio } from 'expo-av';
import i18n from './src/i18n';
import DrawerContent from './navigation/DrawerContent';
import AudioManager from './utils/AudioManager';
import {
  setupNotifications,
  createPlayerNotification,
} from './utils/NotificationManager';
import { ThemeProvider, ThemeContext } from './utils/ThemeContext';
import { startBackgroundAudio } from './utils/BackgroundAudioTask';
import MiniPlayer from './components/MiniPlayer';
import PlayerModal from './components/PlayerModal';

import MainTabs from './navigation/MainTabs';
import DownloadScreen from './screens/DownloadScreen';
import FavoritesScreen from './screens/FavoritesScreen';
import SettingsScreen from './screens/SettingsScreen';
import HelpSupportScreen from './screens/HelpSupportScreen';

export const AudioContext = React.createContext();

const Drawer = createDrawerNavigator();

const BACKGROUND_AUDIO_TASK = 'BACKGROUND_AUDIO_TASK';

TaskManager.defineTask(BACKGROUND_AUDIO_TASK, async () => {
  try {
    if (AudioManager.isPlaying) {
      await AudioManager.playPause();
    }
    return BackgroundFetch.Result.NewData;
  } catch (error) {
    return BackgroundFetch.Result.Failed;
  }
});

const AppContent = () => {
  const [currentSong, setCurrentSong] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const { isDarkMode } = useContext(ThemeContext);
  const [miniPlayerVisible, setMiniPlayerVisible] = useState(false);
  const [playerModalVisible, setPlayerModalVisible] = useState(false);
  const [playlist, setPlaylist] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(-1);

  useEffect(() => {
    setupNotifications();

    const configureBackgroundFetch = async () => {
      await BackgroundFetch.registerTaskAsync(BACKGROUND_AUDIO_TASK, {
        minimumInterval: 15,
        stopOnTerminate: false,
        startOnBoot: true,
      });
    };
    configureBackgroundFetch();

    startBackgroundAudio();

    Audio.setAudioModeAsync({
      staysActiveInBackground: true,
      interruptionModeAndroid: Audio.INTERRUPTION_MODE_ANDROID_DUCK_OTHERS,
      shouldDuckAndroid: true,
      playThroughEarpieceAndroid: false,
      allowsRecordingIOS: false,
      interruptionModeIOS: Audio.INTERRUPTION_MODE_IOS_DUCK_OTHERS,
      playsInSilentModeIOS: true,
    });

    return () => {
      if (AudioManager.sound) {
        AudioManager.sound.unloadAsync();
      }
    };
  }, []);

  const handlePlayPause = async () => {
    await AudioManager.playPause();
    setIsPlaying(AudioManager.isPlaying);
    createPlayerNotification(currentSong, AudioManager.isPlaying);
  };

  const handleNext = async () => {
    if (currentIndex < playlist.length - 1) {
      const nextIndex = currentIndex + 1;
      setCurrentIndex(nextIndex);
      await handleSongSelect(playlist[nextIndex], playlist, nextIndex);
    }
  };

  const handlePrevious = async () => {
    if (currentIndex > 0) {
      const prevIndex = currentIndex - 1;
      setCurrentIndex(prevIndex);
      await handleSongSelect(playlist[prevIndex], playlist, prevIndex);
    }
  };

  const handleSongSelect = async (song, newPlaylist = null, index = -1) => {
    setCurrentSong(song);
    if (newPlaylist) {
      setPlaylist(newPlaylist);
      setCurrentIndex(index !== -1 ? index : newPlaylist.indexOf(song));
    }
    await AudioManager.loadAudio(song, onPlaybackStatusUpdate);
    setIsPlaying(true);
    setMiniPlayerVisible(true);
    createPlayerNotification(song, true);
  };

  const onPlaybackStatusUpdate = (status) => {
    if (status.isLoaded) {
      setIsPlaying(status.isPlaying);
    }
  };

  const toggleMiniPlayer = () => {
    setMiniPlayerVisible(!miniPlayerVisible);
  };

  const togglePlayerModal = () => {
    setPlayerModalVisible(!playerModalVisible);
  };

  const lightTheme = {
    colors: {
      primary: '#2089dc',
      background: '#ffffff',
      text: '#000000',
    },
  };

  const darkTheme = {
    colors: {
      primary: '#bb86fc',
      background: '#121212',
      text: '#ffffff',
    },
  };

  return (
    <RNEThemeProvider theme={isDarkMode ? darkTheme : lightTheme}>
      <I18nextProvider i18n={i18n}>
        <AudioContext.Provider
          value={{
            currentSong,
            isPlaying,
            handlePlayPause: async () => {
              await AudioManager.playPause();
              setIsPlaying(AudioManager.isPlaying);
            },
            handleNext: async () => {
              await AudioManager.playNext();
              setCurrentSong(AudioManager.currentSong);
              setIsPlaying(AudioManager.isPlaying);
            },
            handlePrevious: async () => {
              await AudioManager.playPrevious();
              setCurrentSong(AudioManager.currentSong);
              setIsPlaying(AudioManager.isPlaying);
            },
            handleSongSelect: async (song, newPlaylist = null, index = -1) => {
              if (newPlaylist) {
                AudioManager.setPlaylist(newPlaylist);
                AudioManager.currentIndex =
                  index !== -1 ? index : newPlaylist.indexOf(song);
              }
              await AudioManager.loadAudio(song, onPlaybackStatusUpdate);
              setCurrentSong(song);
              setIsPlaying(true);
              setMiniPlayerVisible(true);
              createPlayerNotification(song, true);
            },
            miniPlayerVisible,
            setMiniPlayerVisible,
            toggleMiniPlayer,
            playerModalVisible,
            togglePlayerModal,
            playlist,
            currentIndex,
          }}>
          <NavigationContainer>
            <View style={{ flex: 1 }}>
              <Drawer.Navigator
                drawerContent={(props) => <DrawerContent {...props} />}
                screenOptions={({ navigation }) => ({
                  headerShown: true,
                  headerStyle: {
                    backgroundColor: isDarkMode ? '#121212' : '#ffffff',
                  },
                  headerTintColor: isDarkMode ? '#ffffff' : '#000000',
                  headerRight: () =>
                    currentSong && (
                      <TouchableOpacity
                        onPress={toggleMiniPlayer}
                        style={{ marginRight: 15 }}>
                        <Icon
                          name="headset"
                          type="material"
                          size={24}
                          color={
                            miniPlayerVisible
                              ? '#1DB954'
                              : isDarkMode
                              ? '#ffffff'
                              : '#000000'
                          }
                        />
                      </TouchableOpacity>
                    ),
                })}>
                <Drawer.Screen
                  name="MainTabs"
                  component={MainTabs}
                  options={{ title: 'Wuno' }}
                />
                <Drawer.Screen name="Download" component={DownloadScreen} />
                <Drawer.Screen name="Favorites" component={FavoritesScreen} />
                <Drawer.Screen name="Settings" component={SettingsScreen} />
                <Drawer.Screen
                  name="HelpSupport"
                  component={HelpSupportScreen}
                />
              </Drawer.Navigator>
              {currentSong && miniPlayerVisible && (
                <View style={styles.miniPlayerContainer}>
                  <MiniPlayer />
                </View>
              )}
            </View>
          </NavigationContainer>
          <PlayerModal
            visible={playerModalVisible}
            onClose={togglePlayerModal}
          />
        </AudioContext.Provider>
      </I18nextProvider>
    </RNEThemeProvider>
  );
};

const App = () => {
  return (
    <ThemeProvider>
      <AppContent />
    </ThemeProvider>
  );
};

const styles = StyleSheet.create({
  miniPlayerContainer: {
    position: 'absolute',
    bottom: 49, // Height of the tab navigator
    left: 0,
    right: 0,
  },
});

export default App;
