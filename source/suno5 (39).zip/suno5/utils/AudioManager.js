import { Audio } from 'expo-av';
import * as BackgroundFetch from 'expo-background-fetch';
import * as TaskManager from 'expo-task-manager';
import * as Notifications from 'expo-notifications';

const BACKGROUND_AUDIO_TASK = 'BACKGROUND_AUDIO_TASK';

class AudioManager {
  constructor() {
    this.sound = null;
    this.isPlaying = false;
    this.currentSong = null;
    this.position = 0;
    this.duration = 0;
    this.playlist = [];
    this.currentIndex = -1;
    this.repeatMode = 'none'; // 'none', 'one', 'all'
  }

  async initAudioMode() {
    await Audio.setAudioModeAsync({
      staysActiveInBackground: true,
      interruptionModeAndroid: Audio.INTERRUPTION_MODE_ANDROID_DO_NOT_MIX,
      shouldDuckAndroid: true,
      playThroughEarpieceAndroid: false,
      allowsRecordingIOS: false,
      interruptionModeIOS: Audio.INTERRUPTION_MODE_IOS_DO_NOT_MIX,
      playsInSilentModeIOS: true,
    });
  }

  async loadAudio(song, onPlaybackStatusUpdate) {
    if (this.sound) {
      await this.sound.unloadAsync();
    }
    const { sound } = await Audio.Sound.createAsync(
      { uri: song.audio_url },
      { shouldPlay: true },
      this.onPlaybackStatusUpdate(onPlaybackStatusUpdate)
    );
    this.sound = sound;
    this.isPlaying = true;
    this.currentSong = song;
    await this.registerBackgroundTask();
    this.updateNotification();
  }

  onPlaybackStatusUpdate = (callback) => (status) => {
    if (status.isLoaded) {
      this.position = status.positionMillis;
      this.duration = status.durationMillis;
      this.isPlaying = status.isPlaying;
      callback(status);

      if (status.didJustFinish) {
        this.handleSongEnd();
      }
    }
  }

  async handleSongEnd() {
    switch (this.repeatMode) {
      case 'one':
        await this.sound.replayAsync();
        break;
      case 'all':
        await this.playNext();
        break;
      case 'none':
      default:
        if (this.currentIndex < this.playlist.length - 1) {
          await this.playNext();
        } else {
          this.isPlaying = false;
          this.updateNotification();
        }
        break;
    }
  }

  async updateNotification() {
    if (this.currentSong) {
      await Notifications.scheduleNotificationAsync({
        content: {
          title: this.currentSong.title,
          body: this.currentSong.artist,
          data: { currentSong: this.currentSong },
        },
        trigger: null,
      });
    }
  }

  async playPause() {
    if (this.sound) {
      if (this.isPlaying) {
        await this.sound.pauseAsync();
      } else {
        await this.sound.playAsync();
      }
      this.isPlaying = !this.isPlaying;
      this.updateNotification();
    }
  }

  async stop() {
    if (this.sound) {
      await this.sound.stopAsync();
      this.isPlaying = false;
      this.updateNotification();
    }
  }

  async setPosition(position) {
    if (this.sound) {
      await this.sound.setPositionAsync(position);
    }
  }

  async setVolume(volume) {
    if (this.sound) {
      await this.sound.setVolumeAsync(volume);
    }
  }

  setRepeatMode(mode) {
    this.repeatMode = mode;
  }

  setPlaylist(songs) {
    this.playlist = songs;
    this.currentIndex = 0;
  }

  async playNext() {
    if (this.currentIndex < this.playlist.length - 1) {
      this.currentIndex++;
      await this.loadAudio(this.playlist[this.currentIndex]);
    } else if (this.repeatMode === 'all') {
      this.currentIndex = 0;
      await this.loadAudio(this.playlist[this.currentIndex]);
    } else {
      this.stop();
    }
  }

  async playPrevious() {
    if (this.currentIndex > 0) {
      this.currentIndex--;
      await this.loadAudio(this.playlist[this.currentIndex]);
    } else if (this.repeatMode === 'all') {
      this.currentIndex = this.playlist.length - 1;
      await this.loadAudio(this.playlist[this.currentIndex]);
    } else {
      this.stop();
    }
  }

  async registerBackgroundTask() {
    TaskManager.defineTask(BACKGROUND_AUDIO_TASK, async () => {
      try {
        if (this.isPlaying) {
          // Here you can add logic to update notification or other background operations
        }
        return BackgroundFetch.Result.NewData;
      } catch (error) {
        return BackgroundFetch.Result.Failed;
      }
    });

    await BackgroundFetch.registerTaskAsync(BACKGROUND_AUDIO_TASK, {
      minimumInterval: 1,
      stopOnTerminate: false,
      startOnBoot: true,
    });
  }
}

export default new AudioManager();