// FavoritesScreen.js
import React, { useState, useEffect, useContext } from 'react';
import { View, FlatList, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import { Text, Icon, useTheme } from 'react-native-elements';
import { useTranslation } from 'react-i18next';
import { AudioContext } from '../App';
import { getFavorites, removeFavorite } from '../utils/favoriteUtils';
import SongListItem from '../components/SongListItem';

const FavoritesScreen = () => {
  const { t } = useTranslation();
  const { theme } = useTheme();
  const { handleSongSelect } = useContext(AudioContext);
  const [favorites, setFavorites] = useState([]);

  useEffect(() => {
    loadFavorites();
  }, []);

  const loadFavorites = async () => {
    const favoriteSongs = await getFavorites();
    setFavorites(favoriteSongs);
  };

  const handleRemoveFavorite = async (song) => {
    Alert.alert(
      t('removeFavorite'),
      t('removeFavoriteConfirm'),
      [
        {
          text: t('cancel'),
          style: 'cancel'
        },
        {
          text: t('remove'),
          onPress: async () => {
            await removeFavorite(song.id);
            loadFavorites(); // Reload favorites after removal
          }
        }
      ]
    );
  };

  const renderItem = ({ item }) => (
    <View style={styles.songItemContainer}>
      <SongListItem
        song={item}
        onPress={() => handleSongSelect(item)}
        theme={theme}
      />
      <TouchableOpacity
        style={styles.removeButton}
        onPress={() => handleRemoveFavorite(item)}
      >
        <Icon
          name="trash-outline"
          type="ionicon"
          color={theme.colors.error}
          size={24}
        />
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <Text h4 style={[styles.header, { color: theme.colors.text }]}>{t('favorites')}</Text>
      {favorites.length > 0 ? (
        <FlatList
          data={favorites}
          renderItem={renderItem}
          keyExtractor={item => item.id}
          contentContainerStyle={styles.listContainer}
        />
      ) : (
        <Text style={[styles.emptyText, { color: theme.colors.grey3 }]}>{t('noFavorites')}</Text>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  header: {
    marginBottom: 20,
  },
  listContainer: {
    flexGrow: 1,
  },
  songItemContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  removeButton: {
    padding: 10,
  },
  emptyText: {
    textAlign: 'center',
    marginTop: 50,
    fontSize: 18,
  },
});

export default FavoritesScreen;