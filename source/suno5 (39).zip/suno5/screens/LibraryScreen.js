import React, { useState, useEffect, useContext } from 'react';
import {
  View,
  StyleSheet,
  Alert,
  RefreshControl,
  TouchableOpacity,
  TextInput,
  FlatList,
  Dimensions,
  ScrollView,
} from 'react-native';
import { Text, Button, useTheme, Icon } from 'react-native-elements';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useTranslation } from 'react-i18next';
import { Ionicons } from '@expo/vector-icons';
import SongListItem from '../components/SongListItem';
import SongDetailsModal from '../components/SongDetailsModal';
import { fetchPlaylist } from '../utils/fetchSongs';
import { AudioContext } from '../App';
import { ThemeContext } from '../utils/ThemeContext';
import { useNavigation } from '@react-navigation/native';

const { width } = Dimensions.get('window');

const LibraryScreen = () => {
  const { t } = useTranslation();
  const { theme } = useTheme();
  const { isDarkMode } = useContext(ThemeContext);
  const { currentSong, isPlaying, handleSongSelect } = useContext(AudioContext);
  const navigation = useNavigation();

  const [playlists, setPlaylists] = useState([]);
  const [currentPlaylist, setCurrentPlaylist] = useState(null);
  const [songs, setSongs] = useState([]);
  const [refreshing, setRefreshing] = useState(false);
  const [detailsModalVisible, setDetailsModalVisible] = useState(false);
  const [selectedSong, setSelectedSong] = useState(null);
  const [newPlaylistUrl, setNewPlaylistUrl] = useState('');
  const [playlistInfo, setPlaylistInfo] = useState(null);

  useEffect(() => {
    loadPlaylists();
  }, []);

  const loadPlaylists = async () => {
    try {
      const savedPlaylists = await AsyncStorage.getItem('playlists');
      if (savedPlaylists) {
        setPlaylists(JSON.parse(savedPlaylists));
      }
    } catch (error) {
      console.error('Error loading playlists:', error);
    }
  };

  const addPlaylist = async () => {
    try {
      let playlistId = newPlaylistUrl;
      if (newPlaylistUrl.includes('suno.ai')) {
        playlistId = newPlaylistUrl.split('/').pop();
      }
      const newPlaylists = [
        ...playlists,
        { id: playlistId, name: `Playlist ${playlists.length + 1}` },
      ];
      await AsyncStorage.setItem('playlists', JSON.stringify(newPlaylists));
      setPlaylists(newPlaylists);
      setNewPlaylistUrl('');
      Alert.alert(t('success'), t('playlistAddedSuccess'));
    } catch (error) {
      console.error('Error adding playlist:', error);
      Alert.alert(t('error'), t('playlistAddFailed'));
    }
  };

  const loadPlaylist = async (playlistId) => {
    try {
      setRefreshing(true);
      const data = await fetchPlaylist(playlistId);
      if (data && data.playlist_clips) {
        setSongs(data.playlist_clips.map((item) => item.clip));
        setPlaylistInfo({
          name: data.name,
          description: data.description,
          user_display_name: data.user_display_name,
          image_url: data.image_url,
        });
        setCurrentPlaylist(playlistId);
      } else {
        console.error('Invalid playlist data:', data);
        Alert.alert(t('error'), t('invalidPlaylistData'));
      }
      setRefreshing(false);
    } catch (error) {
      console.error('Error loading playlist:', error);
      Alert.alert(t('error'), t('playlistLoadFailed'));
      setRefreshing(false);
    }
  };

  const handleRefresh = async () => {
    if (currentPlaylist) {
      await loadPlaylist(currentPlaylist);
    }
  };

  const handlePlaylistLongPress = (index) => {
    Alert.alert(t('managePlaylist'), t('playlistManageOptions'), [
      {
        text: t('editName'),
        onPress: () => editPlaylistName(index),
      },
      {
        text: t('delete'),
        onPress: () => deletePlaylist(index),
        style: 'destructive',
      },
      {
        text: t('cancel'),
        style: 'cancel',
      },
    ]);
  };

  const editPlaylistName = (index) => {
    Alert.prompt(
      t('editPlaylistName'),
      t('enterNewPlaylistName'),
      [
        {
          text: t('cancel'),
          style: 'cancel',
        },
        {
          text: t('edit'),
          onPress: async (newName) => {
            if (newName) {
              const updatedPlaylists = [...playlists];
              updatedPlaylists[index].name = newName;
              setPlaylists(updatedPlaylists);
              await AsyncStorage.setItem(
                'playlists',
                JSON.stringify(updatedPlaylists)
              );
            }
          },
        },
      ],
      'plain-text',
      playlists[index].name
    );
  };

  const deletePlaylist = async (index) => {
    const updatedPlaylists = playlists.filter((_, i) => i !== index);
    setPlaylists(updatedPlaylists);
    await AsyncStorage.setItem('playlists', JSON.stringify(updatedPlaylists));
  };

  const handleSongPress = (song) => {
    handleSongSelect(song, songs, songs.indexOf(song));
  };

  const handleSongLongPress = (song) => {
    setSelectedSong(song);
    setDetailsModalVisible(true);
  };

  const handleEditSong = (song) => {
    navigation.navigate('Create', { song: song });
  };

  const renderPlaylistItem = ({ item, index }) => (
    <TouchableOpacity
      onPress={() => loadPlaylist(item.id)}
      onLongPress={() => handlePlaylistLongPress(index)}
      style={[
        styles.playlistItem,
        {
          backgroundColor: theme.colors.background,
          borderColor: theme.colors.grey3,
          borderRadius: 12,
          borderWidth: 1,
        },
      ]}>
      <Ionicons
        name="musical-notes"
        size={24}
        color={theme.colors.primary}
        style={styles.playlistIcon}
      />
      <Text style={[styles.playlistName, { color: theme.colors.text }]}>
        {item.name}
      </Text>
    </TouchableOpacity>
  );

  return (
    <View
      style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <View style={styles.addPlaylistContainer}>
        <TextInput
          style={[
            styles.input,
            {
              backgroundColor: theme.colors.background,
              color: theme.colors.text,
              borderColor: theme.colors.grey3,
            
              borderWidth: 1,
            },
          ]}
          placeholder={t('enterPlaylistUrlOrId')}
          placeholderTextColor={theme.colors.grey3}
          value={newPlaylistUrl}
          onChangeText={setNewPlaylistUrl}
        />
        <TouchableOpacity
          onPress={addPlaylist}
          style={[styles.addButton, { backgroundColor: theme.colors.primary }]}>
          <Ionicons name="add" size={24} color="white" />
        </TouchableOpacity>
      </View>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.playlistsContainer}>
        {playlists.map((playlist, index) => (
          <TouchableOpacity
            key={index}
            onPress={() => loadPlaylist(playlist.id)}
            onLongPress={() => handlePlaylistLongPress(index)}
            style={[
              styles.playlistItem,
              {
                backgroundColor: theme.colors.background,
                borderColor: theme.colors.grey3,
                borderRadius: 12,
                borderWidth: 1,
              },
            ]}>
            <Ionicons
              name="musical-notes"
              size={24}
              color={theme.colors.primary}
              style={styles.playlistIcon}
            />
            <Text style={[styles.playlistName, { color: theme.colors.text }]}>
              {playlist.name}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {playlistInfo && (
        <View
          style={[
            styles.playlistInfo,
            { backgroundColor: theme.colors.grey5 },
          ]}>
          <Text style={[styles.playlistName, { color: theme.colors.text }]}>
            {playlistInfo.name}
          </Text>
          <Text
            style={[styles.playlistDescription, { color: theme.colors.grey3 }]}>
            {playlistInfo.description}
          </Text>
          <Text style={[styles.playlistCreator, { color: theme.colors.grey3 }]}>
            {t('createdBy', { name: playlistInfo.user_display_name })}
          </Text>
        </View>
      )}

      <FlatList
        data={songs}
        renderItem={({ item }) => (
          <SongListItem
            song={item}
            onPress={() => handleSongPress(item)}
            onLongPress={() => handleSongLongPress(item)}
            isPlaying={currentSong && currentSong.id === item.id && isPlaying}
            theme={theme}
          />
        )}
        keyExtractor={(item) => item.id}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={handleRefresh}
            colors={[theme.colors.primary]}
          />
        }
        ListEmptyComponent={() => (
          <View style={styles.emptyContainer}>
            <Ionicons
              name="musical-notes"
              size={64}
              color={theme.colors.grey3}
            />
            <Text style={[styles.emptyText, { color: theme.colors.grey3 }]}>
              {t('noSongsInPlaylist')}
            </Text>
          </View>
        )}
      />

      <SongDetailsModal
        visible={detailsModalVisible}
        song={selectedSong}
        onClose={() => setDetailsModalVisible(false)}
        onEdit={handleEditSong}
        theme={theme}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  addPlaylistContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  input: {
    flex: 1,
    marginRight: 8,
    padding: 10,
    borderRadius: 25,
  },
  addButton: {
    padding: 10,
    borderRadius: 25,
  },
  playlistsContainer: {
    maxHeight: 100,
    marginBottom: 16,
  },
  playlistItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    marginRight: 8,
    borderRadius: 8,
    width: width * 0.4,
  },
  playlistIcon: {
    marginRight: 8,
  },
  playlistName: {
    fontSize: 14,
    fontWeight: 'bold',
  },
  playlistInfo: {
    padding: 16,
    marginBottom: 16,
    borderRadius: 8,
  },
  playlistDescription: {
    fontSize: 14,
    marginTop: 4,
  },
  playlistCreator: {
    fontSize: 12,
    marginTop: 4,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 64,
  },
  emptyText: {
    marginTop: 16,
    fontSize: 18,
    textAlign: 'center',
  },
});

export default LibraryScreen;
