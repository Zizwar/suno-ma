import React, { useState, useEffect, useContext } from 'react';
import { View, ScrollView, StyleSheet, Switch, Alert, TextInput, TouchableOpacity, Modal } from 'react-native';
import { Text, Button, Icon, Divider } from 'react-native-elements';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useTranslation } from 'react-i18next';
import { Ionicons } from '@expo/vector-icons';
import { ThemeContext } from '../utils/ThemeContext';

const SettingsScreen = () => {
  const { t, i18n } = useTranslation();
  const [notifications, setNotifications] = useState(true);
  const [currentLanguage, setCurrentLanguage] = useState(i18n.language);
  const [settings, setSettings] = useState([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [currentSetting, setCurrentSetting] = useState(null);
  const [newName, setNewName] = useState('');
  const [newSess, setNewSess] = useState('');
  const [newCookie, setNewCookie] = useState('');
  const [autoPlay, setAutoPlay] = useState(false);
  const [dataUsage, setDataUsage] = useState('0 MB');
  const [storageUsage, setStorageUsage] = useState('0 MB');

  const { isDarkMode, toggleDarkMode } = useContext(ThemeContext);

  useEffect(() => {
    loadSettings();
    // Симуляция загрузки использования данных и хранилища
    simulateDataUsage();
    simulateStorageUsage();
  }, []);

  const loadSettings = async () => {
    try {
      const savedSettings = await AsyncStorage.getItem('settings');
      if (savedSettings) {
        setSettings(JSON.parse(savedSettings));
      }
      const savedLanguage = await AsyncStorage.getItem('userLanguage');
      if (savedLanguage) {
        setCurrentLanguage(savedLanguage);
        i18n.changeLanguage(savedLanguage);
      }
      const savedAutoPlay = await AsyncStorage.getItem('autoPlay');
      if (savedAutoPlay !== null) {
        setAutoPlay(JSON.parse(savedAutoPlay));
      }
    } catch (error) {
      console.error('Error loading settings:', error);
    }
  };

  const simulateDataUsage = () => {
    // Симуляция использования данных
    const usage = Math.floor(Math.random() * 1000);
    setDataUsage(`${usage} MB`);
  };

  const simulateStorageUsage = () => {
    // Симуляция использования хранилища
    const usage = Math.floor(Math.random() * 5000);
    setStorageUsage(`${usage} MB`);
  };

  const saveSettings = async (newSettings) => {
    try {
      await AsyncStorage.setItem('settings', JSON.stringify(newSettings));
      setSettings(newSettings);
    } catch (error) {
      console.error('Error saving settings:', error);
    }
  };

  const changeLanguage = async (lang) => {
    try {
      await AsyncStorage.setItem('userLanguage', lang);
      i18n.changeLanguage(lang);
      setCurrentLanguage(lang);
      Alert.alert(t('languageChanged'), t('languageChangedMessage'));
    } catch (error) {
      console.error('Error changing language:', error);
    }
  };

  const toggleAutoPlay = async (value) => {
    setAutoPlay(value);
    try {
      await AsyncStorage.setItem('autoPlay', JSON.stringify(value));
    } catch (error) {
      console.error('Error saving autoPlay setting:', error);
    }
  };

  const addOrUpdateSetting = () => {
    if (currentSetting) {
      const updatedSettings = settings.map(setting => 
        setting.id === currentSetting.id ? {...setting, name: newName, sess: newSess, cookie: newCookie} : setting
      );
      saveSettings(updatedSettings);
    } else {
      const newSetting = {
        id: Date.now().toString(),
        name: newName,
        sess: newSess,
        cookie: newCookie,
        isActive: settings.length === 0
      };
      saveSettings([...settings, newSetting]);
    }
    setModalVisible(false);
    clearForm();
  };

  const deleteSetting = (id) => {
    const updatedSettings = settings.filter(setting => setting.id !== id);
    saveSettings(updatedSettings);
  };

  const toggleActive = (id) => {
    const updatedSettings = settings.map(setting => ({
      ...setting,
      isActive: setting.id === id
    }));
    saveSettings(updatedSettings);
  };

  const clearForm = () => {
    setNewName('');
    setNewSess('');
    setNewCookie('');
    setCurrentSetting(null);
  };

  const openModal = (setting = null) => {
    if (setting) {
      setCurrentSetting(setting);
      setNewName(setting.name);
      setNewSess(setting.sess);
      setNewCookie(setting.cookie);
    } else {
      clearForm();
    }
    setModalVisible(true);
  };

  const SettingItem = ({ icon, title, description, action }) => (
    <TouchableOpacity style={styles.settingItem} onPress={action}>
      <View style={styles.settingIcon}>
        <Ionicons name={icon} size={24} color={isDarkMode ? '#ffffff' : '#000000'} />
      </View>
      <View style={styles.settingText}>
        <Text style={[styles.settingTitle, { color: isDarkMode ? '#ffffff' : '#000000' }]}>{title}</Text>
        {description && <Text style={[styles.settingDescription, { color: isDarkMode ? '#cccccc' : '#666666' }]}>{description}</Text>}
      </View>
      <Ionicons name="chevron-forward" size={24} color={isDarkMode ? '#ffffff' : '#000000'} />
    </TouchableOpacity>
  );

  return (
    <ScrollView style={[styles.container, { backgroundColor: isDarkMode ? '#121212' : '#ffffff' }]}>
      <View style={styles.section}>
        <Text style={[styles.sectionTitle, { color: isDarkMode ? '#ffffff' : '#000000' }]}>{t('appSettings')}</Text>
        <View style={styles.settingItem}>
          <View style={styles.settingIcon}>
            <Ionicons name="moon" size={24} color={isDarkMode ? '#ffffff' : '#000000'} />
          </View>
          <View style={styles.settingText}>
            <Text style={[styles.settingTitle, { color: isDarkMode ? '#ffffff' : '#000000' }]}>{t('darkMode')}</Text>
          </View>
          <Switch
            value={isDarkMode}
            onValueChange={toggleDarkMode}
            trackColor={{ false: "#767577", true: "#81b0ff" }}
            thumbColor={isDarkMode ? "#f5dd4b" : "#f4f3f4"}
          />
        </View>
        <View style={styles.settingItem}>
          <View style={styles.settingIcon}>
            <Ionicons name="notifications" size={24} color={isDarkMode ? '#ffffff' : '#000000'} />
          </View>
          <View style={styles.settingText}>
            <Text style={[styles.settingTitle, { color: isDarkMode ? '#ffffff' : '#000000' }]}>{t('notifications')}</Text>
          </View>
          <Switch
            value={notifications}
            onValueChange={setNotifications}
            trackColor={{ false: "#767577", true: "#81b0ff" }}
            thumbColor={notifications ? "#f5dd4b" : "#f4f3f4"}
          />
        </View>
        <SettingItem
          icon="language"
          title={t('language')}
          description={t(currentLanguage)}
          action={() => Alert.alert(
            t('selectLanguage'),
            '',
            [
              { text: 'English', onPress: () => changeLanguage('en') },
                       { text: 'ⵜⴰⵎⴰⵣⵉⵖⵜ', onPress: () => changeLanguage('amz') },
   { text: 'العربية', onPress: () => changeLanguage('ar') },
              { text: 'Français', onPress: () => changeLanguage('fr') },
  
              { text: t('cancel'), style: 'cancel' },
            ]
          )}
        />
        <View style={styles.settingItem}>
          <View style={styles.settingIcon}>
            <Ionicons name="play-circle" size={24} color={isDarkMode ? '#ffffff' : '#000000'} />
          </View>
          <View style={styles.settingText}>
            <Text style={[styles.settingTitle, { color: isDarkMode ? '#ffffff' : '#000000' }]}>{t('autoPlay')}</Text>
          </View>
          <Switch
            value={autoPlay}
            onValueChange={toggleAutoPlay}
            trackColor={{ false: "#767577", true: "#81b0ff" }}
            thumbColor={autoPlay ? "#f5dd4b" : "#f4f3f4"}
          />
        </View>
      </View>

      <Divider style={[styles.divider, { backgroundColor: isDarkMode ? '#ffffff' : '#000000' }]} />

      <View style={styles.section}>
        <Text style={[styles.sectionTitle, { color: isDarkMode ? '#ffffff' : '#000000' }]}>{t('accountSettings')}</Text>
        <SettingItem
          icon="person"
          title={t('accountInfo')}
          action={() => {/* Navigate to Account Info */}}
        />
        <SettingItem
          icon="lock-closed"
          title={t('privacySettings')}
          action={() => {/* Navigate to Privacy Settings */}}
        />
      </View>

      <Divider style={[styles.divider, { backgroundColor: isDarkMode ? '#ffffff' : '#000000' }]} />

      <View style={styles.section}>
        <Text style={[styles.sectionTitle, { color: isDarkMode ? '#ffffff' : '#000000' }]}>{t('dataAndStorage')}</Text>
        <SettingItem
          icon="cellular"
          title={t('dataUsage')}
          description={dataUsage}
          action={() => {/* Show detailed data usage */}}
        />
        <SettingItem
          icon="save"
          title={t('storageUsage')}
          description={storageUsage}
          action={() => {/* Show detailed storage usage */}}
        />
        <SettingItem
          icon="trash"
          title={t('clearCache')}
          action={() => Alert.alert(t('clearCache'), t('clearCacheConfirm'), [
            { text: t('cancel'), style: 'cancel' },
            { text: t('clear'), onPress: () => {/* Clear cache logic */} }
          ])}
        />
      </View>

      <Divider style={[styles.divider, { backgroundColor: isDarkMode ? '#ffffff' : '#000000' }]} />

      <View style={styles.section}>
        <Text style={[styles.sectionTitle, { color: isDarkMode ? '#ffffff' : '#000000' }]}>{t('cookieManagement')}</Text>
        {settings.map((setting) => (
          <View key={setting.id} style={styles.settingItem}>
            <View style={styles.settingIcon}>
              <Ionicons name="key" size={24} color={isDarkMode ? '#ffffff' : '#000000'} />
            </View>
            <View style={styles.settingText}>
              <Text style={[styles.settingTitle, { color: isDarkMode ? '#ffffff' : '#000000' }]}>{setting.name}</Text>
              <Text style={[styles.settingDescription, { color: isDarkMode ? '#cccccc' : '#666666' }]}>{setting.isActive ? t('active') : t('inactive')}</Text>
            </View>
            <View style={styles.settingActions}>
              <TouchableOpacity onPress={() => toggleActive(setting.id)}>
                <Ionicons name={setting.isActive ? "radio-button-on" : "radio-button-off"} size={24} color={isDarkMode ? '#ffffff' : '#000000'} />
              </TouchableOpacity>
              <TouchableOpacity onPress={() => openModal(setting)}>
                <Ionicons name="create" size={24} color={isDarkMode ? '#ffffff' : '#000000'} />
              </TouchableOpacity>
              <TouchableOpacity onPress={() => deleteSetting(setting.id)}>
                <Ionicons name="trash" size={24} color={isDarkMode ? '#ffffff' : '#000000'} />
              </TouchableOpacity>
            </View>
          </View>
        ))}
        <Button
          title={t('addNewSetting')}
          onPress={() => openModal()}
          icon={<Icon name="add" size={20} color="white" />}
          buttonStyle={[styles.addButton, { backgroundColor: isDarkMode ? '#bb86fc' : '#2089dc' }]}
        />
      </View>

      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.centeredView}>
          <View style={[styles.modalView, { backgroundColor: isDarkMode ? '#1e1e1e' : '#ffffff' }]}>
            <Text style={[styles.modalTitle, { color: isDarkMode ? '#ffffff' : '#000000' }]}>
              {currentSetting ? t('editSetting') : t('addNewSetting')}
            </Text>
            <TextInput
              style={[styles.input, { color: isDarkMode ? '#ffffff' : '#000000', backgroundColor: isDarkMode ? '#2c2c2c' : '#f0f0f0' }]}
              placeholder={t('name')}
              placeholderTextColor={isDarkMode ? '#cccccc' : '#666666'}
              value={newName}
              onChangeText={setNewName}
            />
            <TextInput
              style={[styles.input, { color: isDarkMode ? '#ffffff' : '#000000', backgroundColor: isDarkMode ? '#2c2c2c' : '#f0f0f0' }]}
              placeholder="Sess"
              placeholderTextColor={isDarkMode ? '#cccccc' : '#666666'}
              value={newSess}
              onChangeText={setNewSess}
            />
            <TextInput
              style={[styles.input, { color: isDarkMode ? '#ffffff' : '#000000', backgroundColor: isDarkMode ? '#2c2c2c' : '#f0f0f0' }]}
              placeholder="Cookie"
              placeholderTextColor={isDarkMode ? '#cccccc' : '#666666'}
              value={newCookie}
              onChangeText={setNewCookie}
            />
            <View style={styles.modalButtons}>
              <Button
                title={currentSetting ? t('update') : t('add')}
                onPress={addOrUpdateSetting}
                buttonStyle={[styles.modalButton, { backgroundColor: isDarkMode ? '#bb86fc' : '#2089dc' }]}
              />
              <Button
                title={t('cancel')}
                onPress={() => setModalVisible(false)}
                buttonStyle={[styles.modalButton, styles.cancelButton, { backgroundColor: isDarkMode ? '#cf6679' : '#e74c3c' }]}
              />
            </View>
          </View>
        </View>
      </Modal>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
  },
  settingIcon: {
    marginRight: 16,
  },
  settingText: {
    flex: 1,
  },
  settingTitle: {
    fontSize: 16,
    fontWeight: '500',
  },
  settingDescription: {
    fontSize: 14,
    marginTop: 4,
  },
  settingActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    width: 100,
  },
  divider: {
    marginVertical: 16,
  },
  addButton: {
    marginTop: 16,
  },
  centeredView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalView: {
    width: '80%',
    borderRadius: 20,
    padding: 24,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  input: {
    width: '100%',
    padding: 12,
    borderRadius: 8,
    marginBottom: 16,
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
  },
  modalButton: {
    width: '48%',
  },
  cancelButton: {
    backgroundColor: '#e74c3c',
  },
});

export default SettingsScreen;