import React, { useEffect } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { ThemeProvider, Icon } from 'react-native-elements';
import { Audio } from 'expo-av';
import { I18nextProvider } from 'react-i18next';
import i18n from './src/i18n'; 
import MainTabs from './navigation/MainTabs';
import SettingsScreen from './screens/SettingsScreen';
import { linking } from './navigation/linking';

const Stack = createStackNavigator();

const App = () => {
  useEffect(() => {
    setupAudio();
  }, []);

  const setupAudio = async () => {
    try {
      await Audio.setAudioModeAsync({
        staysActiveInBackground: true,
        interruptionModeAndroid: Audio.INTERRUPTION_MODE_ANDROID_DUCK_OTHERS,
        shouldDuckAndroid: true,
        playThroughEarpieceAndroid: false,
        allowsRecordingIOS: false,
        interruptionModeIOS: Audio.INTERRUPTION_MODE_IOS_DUCK_OTHERS,
        playsInSilentModeIOS: true,
      });
    } catch (error) {
      console.error('Error setting up Audio:', error);
    }
  };

  return (
    <I18nextProvider i18n={i18n}>
      <ThemeProvider>
        <NavigationContainer linking={linking}>
          <Stack.Navigator>
            <Stack.Screen
              name="Main"
              component={MainTabs}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Settings"
              component={SettingsScreen}
              options={({ navigation }) => ({
                title: i18n.t('settings'),
                headerLeft: () => (
                  <Icon
                    name="arrow-back"
                    size={24}
                    color="#000"
                    onPress={() => navigation.goBack()}
                  />
                ),
              })}
            />
          </Stack.Navigator>
        </NavigationContainer>
      </ThemeProvider>
    </I18nextProvider>
  );
};

export default App;