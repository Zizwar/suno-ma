import React, { useState, useEffect } from 'react';
import { View, ScrollView, StyleSheet, Switch, Alert } from 'react-native';
import { ListItem, Text, Button } from 'react-native-elements';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useTranslation } from 'react-i18next';

const SettingsScreen = () => {
  const { t, i18n } = useTranslation();
  const [darkMode, setDarkMode] = useState(true);
  const [notifications, setNotifications] = useState(true);
  const [currentLanguage, setCurrentLanguage] = useState(i18n.language);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const savedLanguage = await AsyncStorage.getItem('userLanguage');
      if (savedLanguage) {
        setCurrentLanguage(savedLanguage);
        i18n.changeLanguage(savedLanguage);
      }
 
    } catch (error) {
      console.error('Error loading settings:', error);
    }
  };

  const changeLanguage = async (lang) => {
    try {
      await AsyncStorage.setItem('userLanguage', lang);
      i18n.changeLanguage(lang);
      setCurrentLanguage(lang);
      Alert.alert(t('languageChanged'), t('languageChangedMessage'));
    } catch (error) {
      console.error('Error changing language:', error);
    }
  };

  return (
    <ScrollView style={styles.container}>
      <ListItem bottomDivider containerStyle={styles.listItem}>
        <ListItem.Content>
          <ListItem.Title style={styles.text}>{t('darkMode')}</ListItem.Title>
        </ListItem.Content>
        <Switch
          value={darkMode}
          onValueChange={setDarkMode}
          trackColor={{ false: "#767577", true: "#81b0ff" }}
          thumbColor={darkMode ? "#f5dd4b" : "#f4f3f4"}
        />
      </ListItem>
      <ListItem bottomDivider containerStyle={styles.listItem}>
        <ListItem.Content>
          <ListItem.Title style={styles.text}>{t('notifications')}</ListItem.Title>
        </ListItem.Content>
        <Switch
          value={notifications}
          onValueChange={setNotifications}
          trackColor={{ false: "#767577", true: "#81b0ff" }}
          thumbColor={notifications ? "#f5dd4b" : "#f4f3f4"}
        />
      </ListItem>
      <ListItem bottomDivider containerStyle={styles.listItem}>
        <ListItem.Content>
          <ListItem.Title style={styles.text}>{t('language')}</ListItem.Title>
          <ListItem.Subtitle style={styles.subtitle}>{t('currentLanguage')}: {t(currentLanguage)}</ListItem.Subtitle>
        </ListItem.Content>
      </ListItem>
      <View style={styles.languageButtons}>
        <Button
          title={t('english')}
          onPress={() => changeLanguage('en')}
          buttonStyle={[styles.languageButton, currentLanguage === 'en' && styles.activeLanguage]}
        />
        <Button
          title={t('arabic')}
          onPress={() => changeLanguage('ar')}
          buttonStyle={[styles.languageButton, currentLanguage === 'ar' && styles.activeLanguage]}
        />
        <Button
          title={t('french')}
          onPress={() => changeLanguage('fr')}
          buttonStyle={[styles.languageButton, currentLanguage === 'fr' && styles.activeLanguage]}
        />
           <Button
          title={t('tamazight')}
          onPress={() => changeLanguage('amz')}
          buttonStyle={[styles.languageButton, currentLanguage === 'amz' && styles.activeLanguage]}
        />
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  listItem: {
    backgroundColor: '#222',
  },
  text: {
    color: '#fff',
  },
  subtitle: {
    color: '#888',
  },
  languageButtons: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 20,
  },
  languageButton: {
    backgroundColor: '#444',
    paddingHorizontal: 20,
  },
  activeLanguage: {
    backgroundColor: '#81b0ff',
  },
});

export default SettingsScreen;