// suno5/screens/HomeScreen.js
import React, { useState, useEffect } from 'react';
import { View, ScrollView, TouchableOpacity, StyleSheet, RefreshControl } from 'react-native';
import { Button, Icon, Text } from 'react-native-elements';
import SongListItem from '../components/SongListItem';
import SongDetailsModal from '../components/SongDetailsModal';
import Player from '../components/Player';
import PlayerModal from '../components/PlayerModal';
import { fetchSongs } from '../utils/fetchSongs';
import { Audio } from 'expo-av';

const HomeScreen = ({ navigation }) => {
  const [songs, setSongs] = useState([]);
  const [refreshing, setRefreshing] = useState(false);
  const [detailsModalVisible, setDetailsModalVisible] = useState(false);
  const [selectedSong, setSelectedSong] = useState(null);
  const [currentSongIndex, setCurrentSongIndex] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [playerModalVisible, setPlayerModalVisible] = useState(false);
  const [sound, setSound] = useState(null);

  useEffect(() => {
    loadSongs();
    return () => {
      if (sound) {
        sound.unloadAsync();
      }
    };
  }, []);

  const loadSongs = async () => {
    try {
      setRefreshing(true);
      const data = await fetchSongs();
      setSongs(data);
      setRefreshing(false);
    } catch (error) {
      console.error('Error loading songs:', error);
      setRefreshing(false);
    }
  };

  const handleRefresh = () => {
    loadSongs();
  };

  const handleSongPress = async (index) => {
    if (sound) {
      await sound.unloadAsync();
    }
    setCurrentSongIndex(index);
    loadAudio(songs[index].audio_url);
  };

  const loadAudio = async (audioUrl) => {
    try {
      const { sound: newSound } = await Audio.Sound.createAsync(
        { uri: audioUrl },
        { shouldPlay: true }
      );
      setSound(newSound);
      setIsPlaying(true);
    } catch (error) {
      console.error('Error loading audio:', error);
    }
  };

  const handleSongLongPress = (song) => {
    setSelectedSong(song);
    setDetailsModalVisible(true);
  };

  const handlePlayPause = async () => {
    if (sound) {
      if (isPlaying) {
        await sound.pauseAsync();
      } else {
        await sound.playAsync();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handleNext = () => {
    const nextIndex = (currentSongIndex + 1) % songs.length;
    handleSongPress(nextIndex);
  };

  const handlePrevious = () => {
    const previousIndex = (currentSongIndex - 1 + songs.length) % songs.length;
    handleSongPress(previousIndex);
  };

  return (
    <View style={styles.container}>
      <ScrollView
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={handleRefresh}
          />
        }
      >
        {songs.map((song, index) => (
          <SongListItem
            key={song.id}
            song={song}
            onPress={() => handleSongPress(index)}
            onLongPress={() => handleSongLongPress(song)}
            isPlaying={index === currentSongIndex && isPlaying}
          />
        ))}
      </ScrollView>

      <SongDetailsModal
        visible={detailsModalVisible}
        song={selectedSong}
        onClose={() => setDetailsModalVisible(false)}
        navigation={navigation}
      />

      {songs[currentSongIndex] && (
        <TouchableOpacity onPress={() => setPlayerModalVisible(true)}>
          <Player 
            currentSong={songs[currentSongIndex]} 
            isPlaying={isPlaying}
            onPlayPause={handlePlayPause}
            onNext={handleNext}
            onPrevious={handlePrevious}
          />
        </TouchableOpacity>
      )}

      <PlayerModal
        visible={playerModalVisible}
        onClose={() => setPlayerModalVisible(false)}
        currentSong={songs[currentSongIndex]}
        isPlaying={isPlaying}
        onPlayPause={handlePlayPause}
        onNext={handleNext}
        onPrevious={handlePrevious}
        songs={songs}
        setCurrentSongIndex={setCurrentSongIndex}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    backgroundColor: '#000' 
  },
});

export default HomeScreen;