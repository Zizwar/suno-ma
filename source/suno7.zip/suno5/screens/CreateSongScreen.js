
import React, { useState, useEffect } from 'react';
import { View, ScrollView, Switch, StyleSheet, Alert, FlatList } from 'react-native';
import { Input, Button, Card, Text, Icon, Overlay } from 'react-native-elements';
import { useTranslation } from 'react-i18next';
import InstrumentModal from '../components/InstrumentModal';
import AdvancedPromptModal from '../components/AdvancedPromptModal';
import { generateSong } from '../utils/fetchSongs';

// Import data for structures and songs
import structuresData from '../data/structures.json';
import songsData from '../data/songs.json';

const CreateSongScreen = ({ navigation, route, isModal = false, onClose }) => {
  const { t } = useTranslation();
  const [title, setTitle] = useState('');
  const [tag, setTag] = useState('');
  const [prompt, setPrompt] = useState('');
  const [makeInstrumental, setMakeInstrumental] = useState(false);
  const [instrumentModalVisible, setInstrumentModalVisible] = useState(false);
  const [songOptionsVisible, setSongOptionsVisible] = useState(false);
  const [structureOptionsVisible, setStructureOptionsVisible] = useState(false);
  const [advancedModalVisible, setAdvancedModalVisible] = useState(false);
  const [songOptions, setSongOptions] = useState([]);
  const [continueClip, setContinueClip] = useState(null);

  useEffect(() => {
    if (route?.params?.song) {
      const { song } = route.params;
      setTitle(song.title);
      setTag(song.metadata?.tags || '');
      setPrompt(song.metadata?.prompt || '');
      setMakeInstrumental(song.metadata?.has_vocal === false);
      setContinueClip(song.metadata?.audio_prompt_id ? { id: song.metadata.audio_prompt_id, time: song.metadata.history?.[0]?.continue_at } : null);
    }
  }, [route?.params?.song]);

  useEffect(() => {
    setSongOptions(songsData);
  }, []);

  const handleModalSelect = (item, type) => {
    if (type === 'instrument' || type === 'structure') {
      setPrompt((prevPrompt) => `${prevPrompt} ${item.value}\n`);
    } else if (type === 'song') {
      setContinueClip(item);
    }
    
    if (type === 'instrument') setInstrumentModalVisible(false);
    if (type === 'structure') setStructureOptionsVisible(false);
    if (type === 'song') setSongOptionsVisible(false);
  };

  const handleGenerate = async () => {
    const requestData = {
      title,
      tags: tag,
      prompt: makeInstrumental ? null : prompt,
      continue_clip_id: continueClip?.id,
      continue_at: continueClip?.time,
      make_instrumental: makeInstrumental,
      mv: 'chirp-v3-5',
    };

    try {
      const result = await generateSong(requestData);
      Alert.alert(t('success'), t('songGeneratedSuccess'));
      if (isModal && onClose) {
        onClose();
      } else {
        navigation.navigate('Library');
      }
    } catch (error) {
      console.error('Error generating song:', error);
      Alert.alert(t('error'), t('songGenerationFailed'));
    }
  };

  const handleUpdatePrompt = (newPrompt) => {
    setPrompt(newPrompt);
  };

  const renderItem = ({ item }) => (
    <Button
      title={item.name || item.text}
      onPress={() => handleModalSelect(item, songOptionsVisible ? 'song' : 'structure')}
      buttonStyle={styles.modalItem}
    />
  );

  return (
    <ScrollView style={styles.container}>
      <Card containerStyle={styles.card}>
        <Card.Title>{isModal ? t('createNewSong') : t('createSong')}</Card.Title>
        <Input
          label={t('title')}
          value={title}
          onChangeText={setTitle}
          placeholder={t('enterSongTitle')}
          inputStyle={styles.input}
        />
        <Input
          label={t('tag')}
          value={tag}
          onChangeText={setTag}
          placeholder={t('enterTag')}
          inputStyle={styles.input}
        />
        <Input
          label={t('prompt')}
          value={prompt}
          onChangeText={handleUpdatePrompt}
          placeholder={t('enterSongPrompt')}
          multiline
          numberOfLines={4}
          textAlignVertical="top"
          disabled={makeInstrumental}
          inputStyle={styles.input}
        />
        <View style={styles.switchContainer}>
          <Text style={styles.switchLabel}>{t('makeInstrumental')}</Text>
          <Switch
            value={makeInstrumental}
            onValueChange={setMakeInstrumental}
            trackColor={{ false: "#767577", true: "#81b0ff" }}
            thumbColor={makeInstrumental ? "#f5dd4b" : "#f4f3f4"}
          />
        </View>
        <View style={styles.buttonContainer}>
          <Button
            title={t('song')}
            icon={<Icon name="queue-music" color="#ffffff" size={24} />}
            buttonStyle={[styles.button, styles.songButton]}
            containerStyle={styles.buttonWrapper}
            onPress={() => setSongOptionsVisible(true)}
          />
          <Button
            title={t('structure')}
            icon={<Icon name="format-list-bulleted" color="#ffffff" />}
            buttonStyle={[styles.button, styles.structureButton]}
            containerStyle={styles.buttonWrapper}
            onPress={() => setStructureOptionsVisible(true)}
          />
          <Button
            title={t('instrument')}
            icon={<Icon name="music-note" color="#ffffff" />}
            buttonStyle={[styles.button, styles.instrumentButton]}
            containerStyle={styles.buttonWrapper}
            onPress={() => setInstrumentModalVisible(true)}
          />
          <Button
            title={t('advanced')}
            icon={<Icon name="edit" color="#ffffff" />}
            buttonStyle={[styles.button, styles.advancedButton]}
            containerStyle={styles.buttonWrapper}
            onPress={() => setAdvancedModalVisible(true)}
          />
        </View>
        <Button
          title={t('generate')}
          onPress={handleGenerate}
          icon={<Icon name="noise-aware" color="#ffffff" />}
          buttonStyle={styles.generateButton}
        />
        {isModal && (
          <Button
            title={t('close')}
            onPress={onClose}
            buttonStyle={styles.closeButton}
          />
        )}
      </Card>

      <InstrumentModal
        visible={instrumentModalVisible}
        onClose={() => setInstrumentModalVisible(false)}
        onSelectInstrument={(value) => handleModalSelect({ value }, 'instrument')}
      />
   
      <Overlay isVisible={structureOptionsVisible} onBackdropPress={() => setStructureOptionsVisible(false)} overlayStyle={styles.optionsOverlay}>
        <Text h4 style={styles.optionsTitle}>{t('selectStructure')}</Text>
        <FlatList
          data={structuresData}
          renderItem={renderItem}
          keyExtractor={(item, index) => index.toString()}
          style={styles.optionsList}
        />
        <Button
          title={t('back')}
          onPress={() => setStructureOptionsVisible(false)}
          buttonStyle={styles.backButton}
        />
      </Overlay>

      <Overlay isVisible={songOptionsVisible} onBackdropPress={() => setSongOptionsVisible(false)} overlayStyle={styles.optionsOverlay}>
        <Text h4 style={styles.optionsTitle}>{t('selectSong')}</Text>
        <FlatList
          data={songOptions}
          renderItem={renderItem}
          keyExtractor={(item, index) => index.toString()}
          style={styles.optionsList}
        />
        <Button
          title={t('back')}
          onPress={() => setSongOptionsVisible(false)}
          buttonStyle={styles.backButton}
        />
      </Overlay>
      
      <AdvancedPromptModal
        visible={advancedModalVisible}
        onClose={() => setAdvancedModalVisible(false)}
        onUpdatePrompt={handleUpdatePrompt}
        prompt={prompt}
      />
    </ScrollView>
  );
};



const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#121212',
  },
  card: {
    backgroundColor: '#1E1E1E',
    borderColor: '#333',
    borderRadius: 10,
    padding: 15,
  },
  input: {
    color: '#fff',
    fontSize: 16,
  },
  switchContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginVertical: 10,
  },
  switchLabel: {
    color: '#fff',
    fontSize: 16,
  },
  buttonContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginTop: 10,
  },
  buttonWrapper: {
    width: '48%',
    marginBottom: 10,
  },
  button: {
    borderRadius: 25,
    paddingVertical: 10,
  },
  songButton: {
    backgroundColor: '#4a90e2',
  },
  structureButton: {
    backgroundColor: '#f39c12',
  },
  instrumentButton: {
    backgroundColor: '#2ecc71',
  },
  advancedButton: {
    backgroundColor: '#e74c3c',
  },
  generateButton: {
    marginTop: 20,
    backgroundColor: '#8e44ad',
    borderRadius: 25,
    paddingVertical: 12,
  },
  closeButton: {
    marginTop: 10,
    backgroundColor: '#95a5a6',
    borderRadius: 25,
    paddingVertical: 12,
  },
  optionsOverlay: {
    width: '80%',
    maxHeight: '80%',
    backgroundColor: '#1E1E1E',
    borderRadius: 10,
    padding: 20,
  },
  optionsTitle: {
    color: '#fff',
    textAlign: 'center',
    marginBottom: 20,
  },
  optionsList: {
    maxHeight: '80%',
  },
  modalItem: {
    backgroundColor: '#333',
    marginBottom: 10,
  },
  backButton: {
    backgroundColor: '#95a5a6',
    marginTop: 10,
  },
});

export default CreateSongScreen;