import React, { useState, useEffect } from 'react';
import { View, TextInput, Button, Text, Switch } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import uuid from 'react-native-uuid';

const AddEditSongScreen = ({ navigation, route }) => {
  const [title, setTitle] = useState('');
  const [tag, setTag] = useState('');
  const [prompt, setPrompt] = useState('');
  const [makeInstrumental, setMakeInstrumental] = useState(false);
  const [song, setSong] = useState(null);

  useEffect(() => {
    if (route.params?.song) {
      const { song } = route.params;
      setTitle(song.title);
      setTag(song.tags);
      setPrompt(song.prompt);
      setMakeInstrumental(song.make_instrumental);
      setSong(song);
    }
  }, [route.params]);

  const saveSong = async () => {
    const newSong = {
      id: song ? song.id : uuid.v4(),
      title,
      tags: tag,
      prompt,
      make_instrumental: makeInstrumental,
      mv: "chirp-v3-5"
    };

    const storedSongs = await AsyncStorage.getItem('songs');
    const songs = storedSongs ? JSON.parse(storedSongs) : [];
    const updatedSongs = song ? songs.map(s => (s.id === song.id ? newSong : s)) : [...songs, newSong];

    await AsyncStorage.setItem('songs', JSON.stringify(updatedSongs));
    navigation.navigate('Home');
  };

  return (
    <View style={{ padding: 16 }}>
      <TextInput
        placeholder="Title"
        value={title}
        onChangeText={setTitle}
        style={{ borderBottomWidth: 1, marginBottom: 16 }}
      />
      <TextInput
        placeholder="Tag"
        value={tag}
        onChangeText={setTag}
        style={{ borderBottomWidth: 1, marginBottom: 16 }}
      />
      <TextInput
        placeholder="Prompt"
        value={prompt}
        onChangeText={setPrompt}
        multiline
        style={{ borderBottomWidth: 1, marginBottom: 16 }}
      />
      <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 16 }}>
        <Text>Make Instrumental</Text>
        <Switch value={makeInstrumental} onValueChange={setMakeInstrumental} />
      </View>
      <Button title="Save Song" onPress={saveSong} />
    </View>
  );
};

export default AddEditSongScreen;
